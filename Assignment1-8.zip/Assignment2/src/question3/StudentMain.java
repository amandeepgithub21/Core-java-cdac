package question3;

//ans3
//Student Grading System:
//Develop a Student class with attributes like name, rollNumber, marks in different subjects. Create methods to calculate the total and average marks, and determine the grade based on the average.

public class StudentMain {
public static void main(String[] args) {
	StudentGrade s=new StudentGrade();
	
	s.readdata();

	s.grade();
	
	s.display();
}
}
