package question3;

import java.awt.DisplayMode;
import java.util.Iterator;
import java.util.Scanner;

public class StudentGrade {
	
	Scanner s= new Scanner(System.in);
	
	String name;
	int rollno;
	int subject;
	int[] marks=new int[5];
	char c;
	int total=0;
	int avg=0;
	
	void readdata() {
		System.out.println("enter the student name ");
		name=s.next();
		System.out.println("enter the student roll num ");
		rollno=s.nextInt();
		System.out.println("enter the no of subject ");
		subject=s.nextInt();
		for(int i=0;i<subject;i++) {
			
			System.out.println("enter marks of"+i+" = ");
			marks[i]=s.nextInt();
		}
		
for(int i=0;i<subject;i++) {
	
			total=marks[i]+total;
		}
avg=total/subject;

	}
	void grade() {
		
		
		if (avg>=90) {
			
			c='A';
			System.out.println(c);
			
		}else if (avg>=80&&avg<90) {
			c='B';
			System.out.println(c);
		}else if (avg>=70&&avg<80) {
			c='C';
			System.out.println(c);
		}else if (avg<70&& avg>=60) {
			c='d';
			System.out.println(c);
		}else {
			c='e';
			System.out.println(c);
		}
		
	}
	void display() {
		
		System.out.println("name "+name+" rollno "+rollno+" subject "+subject+" total "+total+" avg "+avg);
		
	
	}
	
}
