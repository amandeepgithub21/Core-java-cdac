package question6;

public class Library {

	String booklist,memberList,title,author;

	public Library(String booklist, String memberList, String title, String author) {
		super();
		this.booklist = booklist;
		this.memberList = memberList;
		this.title = title;
		this.author = author;
	}

	
}
