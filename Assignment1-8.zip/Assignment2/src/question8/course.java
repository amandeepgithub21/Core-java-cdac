package question8;

public class course {
int cid,fee;
String cname,instructorname;

public course(int cid, String cname,int fee, String instructorname) {
	super();
	this.cid = cid;
	this.fee = fee;
	this.cname = cname;
	this.instructorname = instructorname;
} 

void display()
{
System.out.println("Course Id: "+cid+"Course Name: "+cname+"Course Fee: "+fee+"Instructor Name: "+instructorname);	
}
}
