package question8;

import java.awt.color.CMMException;

public class CourseMain {
	
	public static void main(String[] args) {
		
		courseMangement cm=new courseMangement();

		course[] c=cm.input();
		cm.totalrevenue(c);
	}

}
