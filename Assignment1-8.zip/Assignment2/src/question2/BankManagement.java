package question2;

import java.util.Scanner;

public class BankManagement {

	
int accno;
String nameString;
int balance;
int deposit;
int withrawal;
Scanner s= new Scanner(System.in);

void readdata() {
	
	System.out.println("enter accno ");
	accno=s.nextInt();
	System.out.println("enter name ");
	nameString=s.next();
	System.out.println("enter deposit amount ");
	deposit=s.nextInt();
	System.out.println("enter withrawal amount ");
	withrawal=s.nextInt();
	
}

void display() {
	
	balance=deposit-withrawal;
	
	System.out.println("ACC NO'= "+accno+" name= "+nameString+" Balance= "+ balance);
}


}
