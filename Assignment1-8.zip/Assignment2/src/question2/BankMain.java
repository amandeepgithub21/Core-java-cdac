package question2;

//ans2
//Bank Account Management:
//Design a BankAccount class with properties such as accountNumber, accountHolderName, balance. Include methods to deposit, withdraw, and display the balance.

public class BankMain {
public static void main(String[] args) {
	
	
	BankManagement b1=new BankManagement();
	
	b1.readdata();
	b1.display();
}
	
	
}
