package question5;
class CarMain{
	
public static void main(String[] args) {
		
		
		Carmangement cm=new Carmangement();
	Car[]	cars=cm.cars();
	cm.showcar(cars);
	cm.rentACar(cars);
		

		
	}
}
