package question5;

import java.util.Iterator;
import java.util.Scanner;

public class Car {

	 String model;
	 String registrationNumber;
	 int rentpday;
	public  boolean availble;
	
	 
	
public  Car(String model,String registrationNumber,int rentpday,boolean availble) {
		
		this.model=model;
		this.registrationNumber = registrationNumber;
		this.rentpday=rentpday;
		this.availble =availble;
	}
	 void showcardetails() {
		
		System.out.println("model= "+model+" registrationNumber= "+registrationNumber+"rentpday= "+rentpday+" availbility=  "+availble);
		
	}
	 
}
	 class Carmangement{
		 Car[] cars() {
			 
			 Car[] car =  new Car[4];
				
					car[0]=new Car("m1", "kA01A1001",2000 , true);
					car[1]=new Car("m2", "KA01A5050", 3000, true);
					car[2]=new Car("m3", "KA01A1010", 3000, false);
					car[3]=new Car("m4", "KA01A6862", 3000, true);
				
				
				
				return car;
		 }
		
		 void showcar(Car[] car) {
			 
			 for(int i=0;i<car.length;i++) {
				 car[i].showcardetails();
			 }
			
		 }
		
		
		public void rentACar(Car[] car) {
			
			
			Scanner s=new Scanner(System.in);
			 String str;
			 int noOfdays;
			System.out.println("enetr car  model you want to get on rent ");
			 str=s.next();
			 
			 System.out.println("and for number of days");
			 noOfdays=s.nextInt(); 
			 
			int total=0;
			for(int i=0;i<car.length;i++) {
				
				if (car[i]!= null && car[i].availble ==true&& str.equals(car[i].model )) {
					 
					total=car[i].rentpday*noOfdays;
					System.out.println("car is rented for"+ noOfdays+"days total rent= "+total);
					
				}
				else if (str.equals(car[i].model)&& car[i].availble ==false  ){
					System.out.println("not available");
				}
			}
			
		} 
	 }
