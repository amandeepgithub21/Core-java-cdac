
package question4;


public class EmployeeManagement {
int empid;
String empname;
String desg;
int sal;
int incsal;
int bonus;
int rating;



void read(int id,String name,String deg, int s, int rat) {
	
	empid=id;
	empname=name;
	desg=deg;
	sal=s;
	rating=rat;
	
}
void incsal() {
	
	if (desg=="developer") {
		incsal=sal+15*sal/100; 
		
	}else if (desg=="tester") {
		incsal=sal+15*sal/100; 
	}
	else {
		incsal=sal+10*sal/100;
	}
	
}
	void display() {
		 System.out.println("empid "+empid+" name "+empname+" desigenation "+desg+" sallery "+sal+" rating "+rating);
		 System.out.println("sallery after increment"+incsal);
	}
	
	void bonus() {
		if(rating>10) {
			System.out.print("invalid rating");
			
		}else if(rating<=10 && rating>7) {
			bonus=10*incsal/100;
			System.out.print("10% bonusn amount "+bonus);
			
			
		}else if (rating<=7 && rating>=5) {
			bonus=7*incsal/100;
			System.out.print("7% bonusn amount "+bonus);
			
		}else {
			bonus=5*incsal/100;
			System.out.print("5% bonusn amount "+bonus);
		}
	}

}

