package question4;

//ans4
//Employee Management:
//Create an Employee class with attributes like employeeID, name, designation, and salary. Write methods to increase salary, display employee details, and calculate the annual bonus.


public class EmployeeMain {
public static void main(String[] args) {
	
	EmployeeManagement e1=new EmployeeManagement();
	e1.read(101, "emp1", "developer", 700000,9);
	e1.incsal();
	e1.display();
	e1.bonus();
	
	EmployeeManagement e2=new EmployeeManagement();
	e2.read(101, "emp2", "tester", 600000,8);
	e2.incsal();
	e2.display();
	e2.bonus();
	
	EmployeeManagement e3=new EmployeeManagement();
	e3.read(101, "emp3", "other", 40000,7);
	e3.incsal();
	e3.display();
	e3.bonus();
	
	EmployeeManagement e4=new EmployeeManagement();
	e4.read(101, "emp4", "hr", 40000,4);
	e4.incsal();
	e4.display();
	e4.bonus();
	 
}
}
 