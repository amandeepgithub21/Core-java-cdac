package question9;


public class MainclassProduct {
	public static void main(String[] args) {
		
		
		
		ProductInventoryManagement pm=new ProductInventoryManagement();

		ProductInventory[] p= pm.add();

		pm.showpp(p);
		
		pm.remove(p);
		pm.showpp(p);
	}


}
