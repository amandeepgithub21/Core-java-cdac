package question9;

public class ProductInventory {

	int productID;
	String productName;
	int stockQuantity;
	int price;
	public ProductInventory(int productID, String productName, int stockQuantity, int price) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.stockQuantity = stockQuantity;
		this.price = price;
	}
	void display() {
		
		System.out.println("ProductID: "+productID+"ProductName: "+productName+"StockQuantity: "+stockQuantity+"Price: "+price);
	}
}
