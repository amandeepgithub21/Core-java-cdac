package question9;

import java.util.Scanner;

public class ProductInventoryManagement {

	ProductInventory[] add() {

		ProductInventory[] p = new ProductInventory[3];

		p[0] = new ProductInventory(101, "stock1", 5, 300);
		p[1] = new ProductInventory(102, "stock2", 4, 250);
		p[2] = new ProductInventory(103, "stock3", 9, 100);
		return p;
	}

	void showpp(ProductInventory[] p) {
		for (int i = 0; i < p.length; i++) {
			if (p[i] != null) {
				p[i].display();
			}

		}
	}

	void remove(ProductInventory[] p) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter pid you want to delete");
		int a = s.nextInt();

		for (int i = 0; i < p.length; i++) {

			if (p[i].productID == a) {
				p[i] = null;
				System.out.println("deleted");
			}

		}

	}
}
