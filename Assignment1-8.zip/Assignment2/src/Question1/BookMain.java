package Question1;

//ans1
//Book Management System:
//Create a Book class with attributes like title, author, price, and ISBN. Implement methods to set and get book details, and a method to apply a discount to the book price.

public class BookMain {

	public static void main(String[] args) {
		BookManagement b1= new BookManagement();
		b1.setdata("the engineer", "amandeep", 50000);
		b1.getData();
		b1.discount();
		
	}
}
