package Question1;

import java.util.Scanner;

public class BookManagement {

private String title;
String name;
int price;
int discountedPrice;


	public  void setdata(String t,String n, int p) {
	title=t;
	name=n;
	price=p;
		
	}
	
	public void getData() {
		System.out.println("Title "+ title+" Author "+name+" Price "+ price);
		
	}
	
	public void discount() {
		
		if (price>1000) {
			discountedPrice=price-(price*10/100);
			System.out.println("10% discount "+ " final price after discount "+discountedPrice);
			
		}
		
	}
	
}
