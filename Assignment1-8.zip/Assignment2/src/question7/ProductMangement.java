package question7;

import java.util.Scanner;

public class ProductMangement {
	Scanner s = new Scanner(System.in);

	Product[] cart() 
	{
		Product[] p = new Product[3];

		p[0] = new Product(101, "watch", 500);
		p[1] = new Product(102, "mobile", 5000);
		p[2] = new Product(103, "laptop", 50000);
		return p;
	}

	void displsay(Product[] p) 
	{
		for (int i = 0; i < p.length; i++) 
		{	
			if(p[i] != null)
				p[i].getdata();
			
		}
	}
	void remove(Product[] p) 
	{
		System.out.println("Enter ProductId to delete =");
		int a = s.nextInt();
		for(int i = 0 ; i<p.length;i++)
		{	
			if(p[i].productID == a) {
				p[i]= null ;
				System.out.println("Product is Deleted");
			}
				
		}
		
	}
	
	void update(Product[] p) 
	{
		System.out.println("Enter ProductId you want to update the price  =");
		int a = s.nextInt();
		System.out.println("Update Price is =");
		int b = s.nextInt();
		for(int i = 0 ; i<p.length;i++)
		{	
			if(p[i] != null && p[i].productID == a)
				p[i].price = b ;
		}
		System.out.println("Price is Updated =" +b);
	}
	

	
}
