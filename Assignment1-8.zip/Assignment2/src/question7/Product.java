package question7;

public class Product {

	int productID;
	String productName;
	int price;
//	int quantity;

	 Product(int productID, String productName, int price ) {
		this.productID = productID;
		this.productName = productName;
		this.price = price;
		
	}

void getdata() {
	System.out.println("product id = "+productID+" productname = "+productName+" price ="+price);
	
}
}
