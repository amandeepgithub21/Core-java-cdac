package question7;

public class ProductMain 
{
	public static void main(String[] args) {
		
		ProductMangement pM = new ProductMangement();
		Product[] p = pM.cart();
		pM.displsay(p);
		pM.remove(p);
		pM.displsay(p);
		pM.update( p);
		pM.displsay(p);
	
	}

}
