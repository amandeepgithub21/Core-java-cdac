package question10;


import java.util.Scanner;


class Room {
	
	int roomNumber, ratePerNight;
  boolean availabilityStatus;

public Room(int roomNumber) {
	
	this.roomNumber = roomNumber;
}

}

class Roommanagement{
	
	Scanner s= new Scanner(System.in);
	
	Room[] room() {
		Room[] r=new Room[5];
		 {
			r[0]=new Room(101);
			r[1]=new Room(102);
			r[2]=new Room(103);
			r[3]=new Room(104);
			r[4]=new Room(105);
			
			for (int i = 0; i < r.length; i++) {
				if (i%2==0) {
					r[i].availabilityStatus = true;
					
				}
				else {
					r[i].availabilityStatus = false;
				}
				System.out.println("available:"+r[i].roomNumber+r[i].availabilityStatus);

			}
			
		}
		return r;
	}
	
	void bookroom(Room[] r ) {
		int rent=0;
		
		String s1="ac";
		String s2="nonac";
		
		System.out.println("Enter room number you want to book");
		int n=s.nextInt();
		System.out.println("Enter room type you want to book ac/nonac");
		String roomType=s.next();
		System.out.println("Enter a  number for how many days you want to book room");
		int n2=s.nextInt();
		
		for (int i = 0; i < r.length; i++) {
			if(r[i]!= null && r[i].roomNumber==n && r[i].availabilityStatus==false) 
			  {
			  System.out.println("Not Available"); 
			  }
			 
			  else if ( r[i]!= null && r[i].availabilityStatus==true && r[i].roomNumber== n   &&
					  roomType.equals(s1)) 
					  {
					  rent=4000*n2; 
					  System.out.println("Room is booked for "+n2+" days and rent is: "+rent);
					  
					  } else if (r[i]!= null && r[i].availabilityStatus==true && r[i].roomNumber== n && 
					  roomType.equals(s2) ) 
					  {
						  rent=2000*n2; 
						  System.out.println("Room is booked for "+n2+" days and rent is: "+rent);
					  }
			 
			
		}
		
		
		
	}
} 

public class RoomMain{
	
	public static void main(String[] args) {
		
		Roommanagement rm =new Roommanagement();
		Room[] r=	rm.room();
		rm.bookroom(r);
	}
}
