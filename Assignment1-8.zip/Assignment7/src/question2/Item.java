package question2;

import java.util.HashMap;
import java.util.Scanner;

public class Item {
	String name;
	int quantity,price;
	
	public String getName() {
		return name;
	}
	public Item(String name, int quantity, int price) {
		
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}
	
	
	void printitem() {
				System.out.println(" name: "+name+" quantity: "+quantity+" price: "+price);
	}

	

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

}
