package question2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import javax.xml.crypto.dsig.spec.HMACParameterSpec;

public class ItemMangement {
	Scanner sc = new Scanner(System.in);
	HashMap<Integer, Item> hm;

	public ItemMangement() {
		hm = new HashMap<Integer, Item>();

	}

	public void additem() {
		String name;
		int quantity, price;

		System.out.println("enter id");
		int id = sc.nextInt();
		System.out.println("enter item name");
		name = sc.next();
		System.out.println("enter quantity");
		quantity = sc.nextInt();
		System.out.println("enter price");
		price = sc.nextInt();
		Item item = new Item(name, quantity, price);
		hm.put(id, item);

		System.out.println("item added:");

	}

	public void update(String name) {

		for (Map.Entry<Integer, Item> entry : hm.entrySet()) {
			Item item = entry.getValue();
			if (item.getName().equalsIgnoreCase(name)) {

				System.out.println("enter new quantity");
				int newqty = sc.nextInt();
				item.setQuantity(newqty);
				System.out.println("qty updated" + name);

			}

		}

	}

	public void removeitem( ) {
		System.out.println("enter product id you want to remove");
		int id=sc.nextInt();
	
	
			if (hm.containsKey(id)) 
			{
			hm.remove(id);
				System.out.println("item "+id+" has been removed");
			}else
			{
				System.out.println("id not found");
			}
	}
	public void display() {

		for (Map.Entry<Integer, Item> itemenEntry : hm.entrySet()) {
			System.out.print("id: "+itemenEntry.getKey());
			itemenEntry.getValue().printitem();
		}
	}

}
