package question2;

import java.util.Scanner;

public class MainItem {

	public static void main(String[] args) {
		ItemMangement im=new ItemMangement();
		Scanner sc=new Scanner(System.in);	
		int ch;
		do {
			
		
		System.out.println("enter 1 for add item");
		System.out.println("enter 2 for display");
		System.out.println("enter 3 for update");
		System.out.println("enter 4 for remove item");
		System.out.println("enter 5 for exit");
		ch=sc.nextInt();
		
		switch (ch) {
		
		
		
		case 1:
			im.additem();
			break;
		case 2:
			im.display();
			break;
		case 3:
			 System.out.println("enter item name for qty update"); String name=sc.next();
			  im.update(name);
			  break;
		case 4:
			im.removeitem();
			break;
		case 5:
			System.out.println("exit");
			break;
			default:
				System.out.println("invalid input");
		}
		}
		while(ch != 5);
		

	}
}
