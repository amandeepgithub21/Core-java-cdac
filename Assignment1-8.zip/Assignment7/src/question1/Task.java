package question1;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Stack;

public class Task {
	String title;
	String description;
	boolean isCompleted;

//Use a Queue to manage tasks that are waiting to be started.
//Implement methods to:
//Enqueue a new task (add to the waiting list).
//Dequeue a task (move it to "In Progress").
//View the next task in line without removing it.

	public static void main(String[] args)

	{

		// stack

		Stack<String> stack = new Stack<String>();
		stack.add("in progress");
		stack.push("start working on it");
		stack.push("being worked on");
		stack.push("complete it");
		for (String ele : stack) {
			System.out.println(ele);
		}
		System.out.println("after pop");
		stack.pop();
		String str1 = stack.peek();
		for (String ele : stack) {
			System.out.println(ele);
		}
		System.out.println("peek: " + str1);

		// queue

		/*
		 * PriorityQueue<String> pq =new PriorityQueue<String>();
		 * 
		 * pq.add(" waiting list"); pq.add("In progress"); pq.add("task");
		 * 
		 * for (String ele : pq) { System.out.println(ele); }
		 * System.out.println("after deque in queue"); pq.remove(); for (String ele :
		 * pq) { System.out.println(ele); }
		 */

		// LinkedList
		LinkedList<String> ll = new LinkedList<String>();

		ll.push("task1");
		for (String ele : ll) {
			System.out.println(ele);
		}
		ll.add("task2");
		System.out.println("  add");
		for (String ele : ll) {
			System.out.println(ele);
		}

		System.out.println("after poll in Linked list");
		ll.poll();
		for (String ele : ll) {
			System.out.println(ele);
		}

	}
}
