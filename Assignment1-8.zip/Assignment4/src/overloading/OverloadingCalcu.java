package overloading;

public class OverloadingCalcu {
	
	
public static void main(String[] args) {
	
	calculate(5, 10);
	calculate(10.f, 3.f);
	calculate(10, 2,15);
	calculate(15, 72,105);
	
}  	

static void calculate(int a, int b){
	System.out.println("a+b= "+(a+b));
	
}

static void calculate(float a, float b){
	
	System.out.println("a/b= "+(a/b));

}

static void calculate(int a, int b,int c){
	System.out.println("a*b*c= "+(a*b*c));

	
}
}
