package overloading;

public class OverloadingBookadd {
	
public static void main(String[] args) {
	addBook("book1","author1");
	addBook("book2","author2",2005);
	addBook("book3","author3",2009,"genre3");
}

static void addBook(String title, String author) {
	System.out.println("tittle= "+title+" author= "+author);
	
}

static void addBook(String title, String author, int year) {
	
	System.out.println("tittle= "+title+" author= "+author+" year= "+year);

}

static void addBook(String title, String author, int year, String genre) {
	System.out.println("tittle= "+title+" author= "+author+" year= "+year+" genre= "+genre);

	
}
}
