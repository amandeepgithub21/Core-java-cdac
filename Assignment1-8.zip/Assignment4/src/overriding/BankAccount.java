package overriding;

public class BankAccount {

	int cid;
	String name;
	int balance;
	float rateofintrest;

	public BankAccount(int cid, String name, int balance, float rateofintrest) {

		this.cid = cid;
		this.name = name;
		this.balance = balance;
		this.rateofintrest = rateofintrest;

	}

	void calculateInterest() {
		System.out.println("calculateIntrest mentod of BankAccount base class");

	}
}
