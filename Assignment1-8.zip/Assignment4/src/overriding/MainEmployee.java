package overriding;

public class MainEmployee {
public static void main(String[] args) {
	FullTimeEmployee f=new FullTimeEmployee(101, "abc", 10000, 4000);
	f.calculateSalary();
	
	PartTimeEmployee p=new PartTimeEmployee(1002, "efgh", 8000, 5, 300);
	p.calculateSalary();
	
	ContractEmployee c=new ContractEmployee(1003,"ijkl",5000,4,400);
	
	c.calculateSalary();
}
}
