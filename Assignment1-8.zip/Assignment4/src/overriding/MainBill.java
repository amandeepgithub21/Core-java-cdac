package overriding;

class MainBill {
	public static void main(String[] args) {
		
		
		ResidentialCustomer r= new ResidentialCustomer(20, 5);
		r.printResidentialCustomer();
		r.calculateBill();
		
		
		
		CommercialCustomer c=new CommercialCustomer(400, 10);
		c.printCommercialCustomer();;
		c.calculateBill();
		
		
		IndustrialCustomer i=new IndustrialCustomer(400, 15);
		
		i.printIndustrialCustomer();
		i.calculateBill();
	}
	
	
	
}
