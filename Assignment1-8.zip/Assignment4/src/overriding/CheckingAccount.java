package overriding;

public class CheckingAccount extends BankAccount {
	public CheckingAccount(int cid, String name, int balance, float rateofintrest) {
		super(cid, name, balance, rateofintrest);
		
	}

	
	void calculateInterest()
	{
		float intrest=0;
		intrest=balance*rateofintrest;
		
			System.out.println("total intrest gain checking account= "+intrest);
	}
}
