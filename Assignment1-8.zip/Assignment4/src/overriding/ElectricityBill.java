package overriding;

public class ElectricityBill {

	int unit;
	int rate;
	int totalbill;

	public ElectricityBill(int unit, int rate) {
		super();
		this.unit = unit;
		this.rate = rate;
	}

	void calculateBill() {
		System.out.println("base class calculateBill");
	}

}

class ResidentialCustomer extends ElectricityBill {
	String name = "ResidentialCustomer";

	public ResidentialCustomer(int unit, int rate) {
		super(unit, rate);
		// TODO Auto-generated constructor stub
	}

	void printResidentialCustomer() {

		System.out.println("unit= " + unit + " rate= " + rate + " name= " + name);
	}

	void calculateBill() {

		totalbill = unit * rate;
		System.out.println("totalbill= " + totalbill);
	}
}

class CommercialCustomer extends ElectricityBill {
	String name = "CommercialCustomer";

	public CommercialCustomer(int unit, int rate) {
		super(unit, rate);
		// TODO Auto-generated constructor stub
	}

	void printCommercialCustomer() {

		System.out.println("unit= " + unit + " rate= " + rate + " name= " + name);
	}

	void calculateBill() {

		totalbill = unit * rate;
		System.out.println("totalbill= " + totalbill);
	}

}

class IndustrialCustomer extends ElectricityBill {
	String name = "IndustrialCustomer";

	public IndustrialCustomer(int unit, int rate) {
		super(unit, rate);
		// TODO Auto-generated constructor stub
	}

	void printIndustrialCustomer() {

		System.out.println("unit= " + unit + " rate= " + rate + " name= " + name);
	}

	void calculateBill() {

		totalbill = unit * rate;
		System.out.println("totalbill= " + totalbill);
	}
}
