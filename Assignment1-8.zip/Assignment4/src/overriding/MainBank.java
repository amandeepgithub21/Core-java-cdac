package overriding;

public class MainBank {
	
public static void main(String[] args) {
	BankAccount b;
	b=new SavingAccount(101,"aman",1000000,0.15f);
	b.calculateInterest();
	
	
	 b=new BusinessAccount(101,"raman",1000000,0.10f);
	b.calculateInterest();
	
	b=new CheckingAccount(101,"lucky",1000000,0.5f);
	b.calculateInterest();
}

}
