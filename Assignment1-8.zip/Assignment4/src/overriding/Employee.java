package overriding;

public class Employee {

	
	 int empid;
		String name;
		int basesallery;
		 int totalsal;
		
		public Employee(int empid, String name, int basesallery) {
		
			this.empid = empid;
			this.name = name;
			this.basesallery = basesallery;
		}
	
	
	
	void calculateSalary()
	{
		System.out.println("base class calculateSalary method");
		
	}
}


class FullTimeEmployee extends Employee{
int bonus;
	public FullTimeEmployee(int empid, String name, int basesallery,int bonus) {
		super(empid, name, basesallery);
		this.bonus=bonus;
	}
	
	

	void calculateSalary()
	{
		super.calculateSalary();
		System.out.println("FullTimeEmployee salery"+(basesallery+bonus));
		
	}
	
	
}
class PartTimeEmployee  extends Employee{
int hr;
int rt;
	public PartTimeEmployee(int empid, String name, int basesallery,int hr,
	int rt) {
		super(empid, name, basesallery);
		this.hr=hr;
		this.rt=rt;
	}
	
	void calculateSalary()
	{
		System.out.println("PartTimeEmployee=  "+(basesallery+hr*rt));
		
	}
	
}

class ContractEmployee  extends Employee{
	int hr;
	int rt;
	public ContractEmployee(int empid, String name, int basesallery,int hr,
			int rt) {
		super(empid, name, basesallery);
		this.hr=hr;
		this.rt=rt;
	}
	
	void calculateSalary()
	{
		System.out.println("ContractEmployee=  "+(basesallery+hr*rt));
		
	}
}


