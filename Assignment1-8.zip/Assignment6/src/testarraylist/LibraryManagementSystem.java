package testarraylist;

import java.util.ArrayList;
import java.util.Scanner;

import javax.lang.model.element.Element;

public class LibraryManagementSystem {

	ArrayList<Book> bookCollection;

	public LibraryManagementSystem() {
	
	bookCollection =new ArrayList<Book>();
	}
	
	void addBook(Book book) {
		bookCollection.add(book);
		System.out.println("book added");
		
	}

void removeBook(String isbn) {
	for(int i=0;i<bookCollection.size();i++) {
		if(bookCollection.get(i).isbn.equals(isbn)) {
			bookCollection.remove(i);
			System.out.println("removed is sucessfull");
		}else
		{
			System.out.println("invalid isbn");
		}
	}
	
}

Book searchBook(String title) {
	for(Book book : bookCollection) {
		
		if (book.getTitle().equalsIgnoreCase(title)) {
						return book;
			
		}
		
	}
	return null;
	 
}
void displayAllBooks() {
	for(Book book : bookCollection) {
		
		book.display();
		
	}
}

}