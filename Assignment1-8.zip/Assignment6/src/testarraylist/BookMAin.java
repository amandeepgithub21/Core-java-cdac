package testarraylist;

import java.util.Scanner;

public class BookMAin {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		LibraryManagementSystem lb=new LibraryManagementSystem();
		int ch;
		String title;
		String author; 
		String isbn;
		int publicationYear;
		do
		{
			System.out.println("enter 1 to add book");
			System.out.println("enter 2 to display book");
			System.out.println("enter 3 to remove book ");
			System.out.println("enter 4 to search book");
			System.out.println("enter 5 to get exit from program");
			ch=sc.nextInt();

			switch (ch) {
			case 1: System.out.println("enter titile");
			title=sc.next();
			 System.out.println("enter author name");
			author=sc.next();
			System.out.println("enter isbn");
			isbn=sc.next();
			 System.out.println("enter publicationYear");
			publicationYear=sc.nextInt();
			lb.addBook(new Book(title, author, isbn, publicationYear));
			break;
			case 2:
				System.out.println("all books collection:");
				lb.displayAllBooks();
				break;
			case 3:
				System.out.println("enter isbn to remove book");
				String removeisbn=sc.next();
				lb.removeBook(removeisbn);
				
				break;
			case 4:
				
				System.out.println("enter title to search book");
				String searchtitle=sc.next();
				Book b=lb.searchBook(searchtitle);
				if(b!= null) {
					b.display();
				}else
				{
					System.out.println("not found");
				}
				
				break;
			case 5:
				
				System.out.println("exit program");
				break;
				default:
					System.out.println("invalid input");
					
			}
		}while(ch != 5);
		
		
	}
}
