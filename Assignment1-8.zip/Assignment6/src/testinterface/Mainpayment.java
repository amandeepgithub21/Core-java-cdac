package testinterface;


interface PaymentMethod{
	
	boolean processPayment(double amount);
	String getPaymentDetails();
	void refund(double amount);
	 	
}

class CreditCardPayment implements PaymentMethod{

	
	String cardNumber;
	String cardHolderName;
	String expirationDate;
	String cvv;
	
	

	public CreditCardPayment(String cardNumber, String cardHolderName, String expirationDate, String cvv) {
		
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.expirationDate = expirationDate;
		this.cvv = cvv;
	}

	@Override
	public boolean processPayment(double amount) {
		// TODO Auto-generated method stub
		if (amount>100000) {
			System.out.println("unsuccesfull");
			return false;
			
		}
		else {
			System.out.println("sucessfull");
			return true;
		}
		
	}

	@Override
	public String getPaymentDetails() {
String carddetails= cardHolderName+" "+cardNumber;


		return carddetails;
	}

	@Override
	public void refund(double amount) {
		System.out.println("refund amount"+amount);
		
	}
	
	
}

class PayPalPayment implements PaymentMethod{

	String email;
	
	public PayPalPayment(String email) {
		
		this.email = email;
	}

	@Override
	public boolean processPayment(double amount) {
		if (amount>100000) {
			System.out.println("unsuccesfull");
			return false;
			
		}
		else {
			System.out.println("send payment request to paypal account");
			return true;
		}
	}

	@Override
	public String getPaymentDetails() {
		System.out.println(email);
		return email;
	}

	@Override
	public void refund(double amount) {
		System.out.println("refund amount"+amount);
		
	}
	
	
}

class BankTransferPayment implements PaymentMethod {

	String bankAccountNumber;
	String bankName;
	public BankTransferPayment(String bankAccountNumber, String bankName) {
		
		this.bankAccountNumber = bankAccountNumber;
		this.bankName = bankName;
	}

	@Override
	public boolean processPayment(double amount) {
		
		if (amount>100000) {
			System.out.println("unsuccesfull");
			return false;
			
		}
		else {
			System.out.println("sucessfull");
			return true;
		}
	}

	@Override
	public String getPaymentDetails() {
		String str1= bankName+" "+ bankAccountNumber;
		System.out.println(str1);
		return str1;
	}

	@Override
	public void refund(double amount) {
		System.out.println("refund amount"+amount);
		
	}
	
	
}



public class Mainpayment {
	
public static void main(String[] args) {
	
	
	CreditCardPayment cp=new CreditCardPayment("******6565","aman","10/26","054");
	
	cp.processPayment(5000);
	String string =cp.getPaymentDetails();
	System.out.println(string);
	cp.refund(2000);
	
	PayPalPayment pp =new PayPalPayment("aman@gmail.com");
	
	pp.processPayment(70000);
	pp.getPaymentDetails();
	pp.refund(15000);
	
	BankTransferPayment bp =new BankTransferPayment("546694694964", "aman");
	bp.processPayment(600000);
	bp.getPaymentDetails();
	bp.refund(3000);
	
}
}



