package abstraction;

abstract public class PaymentMethod {

	 abstract void processPayment(double amount);
}
