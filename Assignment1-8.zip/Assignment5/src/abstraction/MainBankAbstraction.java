package abstraction;

public class MainBankAbstraction {
	
public static void main(String[] args) {
	
	PayPal pal=new PayPal();
	pal.processPayment(20000);
	
	CreditCard card=new CreditCard();
	card.processPayment(300000);
}
}
