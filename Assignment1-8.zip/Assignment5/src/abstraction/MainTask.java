package abstraction;


abstract class  Task {
	
	abstract void trackProgress();
	
}


class DevelopmentTask extends Task {

	@Override
	void trackProgress() {
		
		System.out.println(" Development Task");
		
	}
	
	
}

class DesignTask extends Task {

	@Override
	void trackProgress() {
		System.out.println("Design task");
	}
	
	
}
public class MainTask {

	public static void main(String[] args) {
		DevelopmentTask d=new DevelopmentTask();
		
		d.trackProgress();
		
		DesignTask dt=new DesignTask()
;
		dt.trackProgress();
		
	}
}
