package abstraction;

public class PayPal extends PaymentMethod {

	void processPayment(double amont) {
		System.out.println("payment is done by PayPal"+amont);
	}
}
