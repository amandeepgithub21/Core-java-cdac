package abstraction;

public class CreditCard extends PaymentMethod{

	@Override
	void processPayment(double amount) {
		System.out.println(" Paymane is done through Credit Card"+amount);
		
	}

}
