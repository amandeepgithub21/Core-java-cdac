package hasarelation;


public class Car {
String model, make;
Engine e;

public Car(String model, String make,Engine e ) {
	
	this.model = model;
	this.make = make;
	this.e=e;
	
}

void display() {
	
	System.out.println(model+" "+make);
	e.display();
}
}

