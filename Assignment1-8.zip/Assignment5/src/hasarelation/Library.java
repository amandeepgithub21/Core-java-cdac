package hasarelation;

public class Library {
	String name, location;
	Book[] bookList;
	int count;

	public Library(String name, String location ) {

		this.name = name;
		this.location = location;
		bookList = new Book[5];
	}

	public void addBook(Book b) {
		
		bookList[count++] = b;
	}

	public void display() {
		
		System.out.println(name +location);
		for (int i = 0; i < count; i++) {
			System.out.println(bookList[i].author + " " + bookList[i].title + " " + bookList[i].isbn);
		}
	}
}
