package hasarelation;

public class Book {
	String title, author, isbn;

	public Book(String title, String author, String isbn) {

		this.title = title;
		this.author = author;
		this.isbn = isbn;
	}

	void displaybooks() {
		System.out.println("Title: " + title + "Author: " + "ISBN: " + isbn);
	}

}
