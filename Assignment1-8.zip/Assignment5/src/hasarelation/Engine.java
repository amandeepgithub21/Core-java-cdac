package hasarelation;


public class Engine {
String engineNumber, type,  power;

public Engine(String engineNumber, String type, String power) {
	
	this.engineNumber = engineNumber;
	this.type = type;
	this.power = power;
}
void display() {
	
	System.out.println(engineNumber+" "+type+" "+power);
}
}
