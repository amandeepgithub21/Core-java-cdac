package hasarelation;

class MainCar{
	
	public static void main(String[] args) {
	Engine e=new Engine("hgy4545", "di", "100hp");
		Car car=new Car("a1","car_a1",e);
	
				car.display();		
	}
}
