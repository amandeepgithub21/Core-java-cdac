package hasarelation;

public class BookMain {

	public static void main(String[] args) {
		Book b1 = new Book("hbh","ggy","8797");
		Book b2 = new Book("hbh","ggy","666");
		Book b3 = new Book("hbh","ggy","3131");

	
		Library l=new Library("CDAC ", "Banglore");
		
		l.addBook(b1);
		l.addBook(b2);
		l.addBook(b3);
		
		l.display();
	}
	
}
