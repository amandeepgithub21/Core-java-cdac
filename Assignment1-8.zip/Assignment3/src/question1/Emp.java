package question1;

public class Emp {
	
	 int empid;
	String name;
	int basesallery;
	 int totalcompensation;
	
	public Emp(int empid, String name, int basesallery) {
	
		this.empid = empid;
		this.name = name;
		this.basesallery = basesallery;
	}

	void display() {
		
		System.out.print(empid+name+basesallery);
	}
}
class FulltimeEmp extends Emp{
	int annualBonus;



	 public FulltimeEmp(int empid, String name, int basesallery, int annualBonus) {
		 super(empid, name, basesallery);
			this.annualBonus = annualBonus;	}

	void printFulltimeEmpdetail() {
		 
		 super.display();
		 System.out.println("annualBonus = "+annualBonus);
		 System.out.println("totalcompensation = "+totalcompensation);

	 }
	 int fulltimecompensation() {
		 
		 totalcompensation=annualBonus+basesallery;
		return totalcompensation;
	 }
	
	
}
class ParttimeEmp extends Emp{
	int horsworked;
	int hourlyrate;
	public ParttimeEmp(int empid, String name, int basesallery, int horsworked, int hourlyrate) {
		super(empid, name, basesallery);
		this.horsworked = horsworked;
		this.hourlyrate = hourlyrate;
	}
	
	void printPartimeEmpdetail() {
		super.display();
		System.out.println(horsworked+" <hrw    hlr>" +hourlyrate);
		 System.out.println("totalcompensation = "+totalcompensation);

	}
	int parttimeCompensation() {
		
		totalcompensation=horsworked*hourlyrate+basesallery;
	
	return totalcompensation;
		
	}
}
