package question1;

public class MainEmpclass {
	public static void main(String[] args) {
		
				
				FulltimeEmp f=new FulltimeEmp(1,"emp1",2000,200);
				f.fulltimecompensation();
				f.printFulltimeEmpdetail();
				 
				
				ParttimeEmp p= new ParttimeEmp(2,"emp2",500, 8, 1000);
				p.parttimeCompensation();
				p.printPartimeEmpdetail();
}
}