package question4;

public class Institution{
	String name;
	String location;
	
	public Institution(String name, String location) {
		
		
		this.name = name;
		this.location = location;
	}
	void print() {
		System.out.println("name= "+name+"location= "+location);
	}
	
}

