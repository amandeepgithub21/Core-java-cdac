package question4;

public class MainInstitution {
	
public static void main(String[] args) {
	School s=new School("vibgeyor", "banglore", 5000);
	
	s.getSummary();
	
	College c=new College("pes", "dodamangla road banglore ", 20000);
	
	c.getSummary();
}
}
