package question4;

public class College extends Institution {
int numberOfFaculties;




public College(String name, String location,int numberOfFaculties) {
	super(name,location);
	this.numberOfFaculties = numberOfFaculties;
}




void getSummary() {
	
	super.print();
	System.out.println("numberOfFaculties= "+numberOfFaculties);
	System.out.println(" this is the summery of college");
}
}


