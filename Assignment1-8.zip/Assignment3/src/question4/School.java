package question4;

public class School extends Institution  {
int numberOfStudents;
	public School(String name, String location,int numberOfStudents) {
		super(name, location);
		this.numberOfStudents=numberOfStudents;
	}
	void getSummary() {
		
		super.print();
		System.out.println("numberOfStudents= "+numberOfStudents);
		System.out.println(" this is the summery of school");
	}
}
