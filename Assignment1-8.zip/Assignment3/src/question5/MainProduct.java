package question5;

public class MainProduct {
	
public static void main(String[] args) {
	Electronics electronics=new Electronics(101, "watch", 1);
	electronics.print();
	
	Electronics e2=new Electronics(101, "mobile", 2);
	e2.print();
	
	
	Clothing clothing=new Clothing(110, "shirt", "l");
	clothing.print();
	Clothing c2=new Clothing(110, "trouser", "32");
	c2.print();
	
}

}
