package question5;

public class Product{
	int productId ;
	String productName;
	
	

	public Product(int productId, String productName) {
		
		this.productId = productId;
		this.productName = productName;
	}
void displayProductInfo() {
		System.out.println("productId = "+productId+"productname= "+productName);
	}
	
}