package question5;


public class Electronics extends Product {
int warrantyPeriod;

public Electronics(int productId, String productName, int warrantyPeriod) {
	super(productId,productName);
	this.warrantyPeriod = warrantyPeriod;
}
void print() {
	super.displayProductInfo();
	System.out.println("warrantyPeriod= "+warrantyPeriod);
}

}