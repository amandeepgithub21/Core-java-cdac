package question5;

public class Clothing extends Product {
	String size;

public Clothing(int productId, String productName, String size) {
		super(productId, productName);
		this.size = size;
	}
void print() {
	super.displayProductInfo();
	System.out.println("size= "+size);
}


}
