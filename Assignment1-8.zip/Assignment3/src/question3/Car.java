package question3;

public class Car extends Vehicles{
int noofdoor;

public Car(String makefor, String model,int noofdoor) {
	super(makefor, model);
	this.noofdoor = noofdoor;
}

void displaycar() {
	super.display();
	System.out.println(noofdoor);
	;
}
}
