package question3;

import java.awt.DisplayMode;

public class MainVehicle {
public static void main(String[] args) {
	
	Car car= new Car("persnal", "Wrangler",5);
	
	car.displaycar();
	
	Truck truck=new Truck("Good Transport", "407", 15);
	truck.displaytruck();
}
}
