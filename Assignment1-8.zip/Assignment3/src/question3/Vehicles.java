package question3;

public class Vehicles{
	String makefor;
	String model;
	public Vehicles(String makefor, String model) {
	
		this.makefor = makefor;
		this.model = model;
	}
	
void display() {
	System.out.print("makefor= "+makefor+"model= "+model);
	
}
	
}