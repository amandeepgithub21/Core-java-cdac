package question3;

public class Truck extends Vehicles {
	int cargoCapacity;
public Truck(String makefor, String model , int cargoCapacity )
		{
		super(makefor, model);
		this.cargoCapacity = cargoCapacity;;
	}

void displaytruck(){
	
	super.display();
	System.out.println("cargoCapacity= "+cargoCapacity);
}




}
