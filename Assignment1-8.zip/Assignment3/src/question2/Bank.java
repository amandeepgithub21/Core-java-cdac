package question2;

public class Bank {
int accountNumber;
int balance;
public Bank(int accountNumber, int balance) {
	super();
	this.accountNumber = accountNumber;
	this.balance = balance;
}
void displaybankk() {
	System.out.print("accountNumber = "+accountNumber+" balance ="+balance);
}
}


class SavingAccount extends Bank {
	float interestRate;

	public SavingAccount(int accountNumber, int balance, float interestRate) {
		super(accountNumber, balance);
		this.interestRate = interestRate;
	}
	void printsavingdetail() {
		super.displaybankk();
		System.out.println(" interestRate ="+interestRate);
	}
	
	void intrest() {
		float intrate= balance*interestRate;
		System.out.println("intrate"+intrate);
		
	}
	
}
class CurrentAccount extends Bank{
	int overdraftLimit;
	public CurrentAccount(int accountNumber, int balance,int overdraftLimit) {
		super(accountNumber, balance);
		this.overdraftLimit=overdraftLimit;
	}
	void printcurrentdetail() {
		
		super.displaybankk();
		System.out.println("overdraftLimit ="+overdraftLimit);
	}
void  overdraftlimt(int amount) {
	if(balance<amount)
	{
		int limit;
		limit=balance-500;
		System.out.println("limit ="+limit);
		}
	else {
		System.out.println("balance ="+balance);
	}
	 
}

}