package question2;

public class MainBankClass {
	public static void main(String[] args) {
		SavingAccount s = new SavingAccount(101, 1000, 0.02f);
		s.printsavingdetail();
		s.intrest();

		CurrentAccount c = new CurrentAccount(102, 2000, 500);

		c.printcurrentdetail();

		c.overdraftlimt(200);
	}
}
