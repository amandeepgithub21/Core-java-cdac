package Assignment1;

public class UniqueElement {

	
	    public static int findSingleNumber(int[] nums) {
	        int result = 0;
	        for (int num : nums) {
	            result ^= num; // XOR operation
	        }
	        return result; // The single number will remain
	    }

	    public static void main(String[] args) {
	        int[] nums = {1, 4, 2, 1, 2,5,4,};
	        int singleNumber = findSingleNumber(nums);
	        System.out.println("The single number is: " + singleNumber);
	    }
	}

