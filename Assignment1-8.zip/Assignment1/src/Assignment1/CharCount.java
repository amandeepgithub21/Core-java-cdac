package Assignment1;

import java.util.Scanner;

public class CharCount {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String str = sc.next();

		System.out.println("Enter a char from String you want to count no of occurence");
		char ch = sc.next().charAt(0);
		
		
		int len = str.length();

        int count  = 0;
		for (int i = 0; i < len; i++) {
			if(str.charAt(i) == ch) {
				count++;
			}
		}	
		
		System.out.print(count);
	}
}
