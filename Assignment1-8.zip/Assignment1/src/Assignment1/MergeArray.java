package Assignment1;

public class MergeArray {

	public static void main(String[] args) {
		
		int[] arr1= {1,3,5,7,9};
		int[] arr2= {2,4,6,8,10};
		
		int[] arr3=new int[arr1.length+arr2.length];
		
		
	}
}
