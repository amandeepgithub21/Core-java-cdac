package Assignment1;

import java.util.Iterator;
import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
Scanner s= new Scanner(System.in);
		
		String str1,str3="";
		
		
		char ch;
		System.out.println("enter the String ");
		str1=s.next();
	int a=	str1.length();
	
	
		for (int i = 0; i < a; i++) {
			ch=str1.charAt(i);
			str3=ch+str3;
		}
		if (str1.equals(str3)) {
			System.out.println("pailndrome");
		}else {
			System.out.println("not a pailndrome");
		}
		System.out.println(str3);
		
	}
}
