package Assignment1;

import java.util.Scanner;

public class SumofDigit {
	
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a number");
	int num = sc.nextInt();
	
	String str=String.valueOf(num);
	int len=str.length();
	int sum=0;
	for (int i = 0; i <len; i++) {
		sum= sum+num%10;
		num=num/10;
		
	}
	System.out.println(sum);
}
}
