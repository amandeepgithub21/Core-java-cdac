package Assignment1;

import java.util.Scanner;

public class Temperature {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter temp in celcius");
		float temp = sc.nextFloat();
		
		float far=(temp *9/5)+32;
		System.out.println(far);
	}
	

}
