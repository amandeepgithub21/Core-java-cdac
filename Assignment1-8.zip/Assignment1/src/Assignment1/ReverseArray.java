 package Assignment1;

import java.util.Iterator;

public class ReverseArray {
public static void main(String[] args) {
	
	int[] arr= {1,2,5,6,8};
	System.out.println("reverse array:");
	for (int i = arr.length-1; i >= 0; i--) {
		System.out.println(arr[i]);
	}	
}
}
