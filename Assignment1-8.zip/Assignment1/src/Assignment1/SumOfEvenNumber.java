package Assignment1;

import java.util.Scanner;

public class SumOfEvenNumber {
	
	public static void main(String[] args) {
		int n;
		int sum = 0;
		System.out.println("enter a num");
		
		Scanner sc=new Scanner(System.in);
		
		n=sc.nextInt();
		
		for(int i=0;i<n;i++) {
			if (i%2==0) {
				sum=sum+i;
				
			}
		}
		System.out.println(sum);
	}

}
