 package Assignment1;

import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;

public class MinMaxArray {

	public static void main(String[] args) {

		
		int[] a= {11,3,5,8,56,2,55};
		int max=0;
		int min=a[0];
		for (int i = 0; i < a.length; i++) {
			
			if (a[i]>=max) {
				max=a[i];
				
			}
			
	
		}
		System.out.println("max: "+max);
		
		
		for (int i = 0; i < a.length; i++) {
			if (a[i]<=min) {
				min=a[i];
			}
		}
		System.out.println("min: "+min);
	}
	
}
