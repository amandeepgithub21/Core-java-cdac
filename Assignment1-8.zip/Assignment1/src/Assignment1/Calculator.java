 package Assignment1;

import java.util.Scanner;



public class Calculator {

	public static void main(String[] args) {
		int a=10;
		int b=5;
		int ch;
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter choice");
		ch=scanner.nextInt();

		switch (ch) {
		
		case 1:
			System.out.println("sum= "+ (a+b));
			break;	
		case 2:
			System.out.println("diff= "+ (a-b));
			break;
		case 3:
			System.out.println("multi= "+ (a*b));
			break;
		case 4:
			System.out.println("div= "+ (a/b));
			break;
		case 5:
			System.out.println("modulus= "+ (a%b));
			break;
		default:
			System.out.println("invalid input");
		}

	}


}


