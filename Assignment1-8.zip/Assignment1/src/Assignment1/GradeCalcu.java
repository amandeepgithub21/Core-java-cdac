 package Assignment1;

import java.util.Scanner;

import javax.sql.rowset.JoinRowSet;

public class GradeCalcu {

	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		
		String name;
		int rollno;
		int mark;
		
		System.out.println("enter the student name ");
		name=s.next();
		System.out.println("enter the student roll num ");
		rollno=s.nextInt();
		System.out.println("enter the marks ");
		mark=s.nextInt();
		
		
if (mark>=90) {
			
			
			System.out.println(name+" "+rollno+" "+"A");
			
		}else if (mark>=80&&mark<90) {
			
			System.out.println(name+" "+rollno+" "+"B");
		}else if (mark>=70&&mark<80) {
			
			System.out.println(name+" "+rollno+" "+"C");
		}else if (mark<70&& mark>=60) {
			
			System.out.println(name+" "+rollno+" "+"D");
		}else {
			
			System.out.println(name+" "+rollno+" "+"E");
		}
		
	}
	

}
