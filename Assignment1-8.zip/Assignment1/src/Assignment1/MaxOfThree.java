package Assignment1;

import java.util.Scanner;

public class MaxOfThree {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the num one: ");
		int num1=s.nextInt();
		System.out.println("Enter the num two: ");
		int num2 =s.nextInt();
		System.out.println("Enter the num three: ");
		int num3=s.nextInt();
		
		if (num1>num2&&num1>num3) {
			System.out.println("num1 is greater");
			
		} else 	if (num2>num1&&num2>num3) {
			System.out.println("num2 is greater");
			
		}else {
			System.out.println("num3 is grater");
		}

	}
}
