package question3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class PrimitiveDatatype {
	
	
public static void main(String[] args) {

	String filename="primitivedata";
	
	
	try {
		DataOutputStream dos=new DataOutputStream(new FileOutputStream(filename));
	
		dos.writeInt(15);
		dos.writeBoolean(true);
		dos.writeDouble(15.54);
		System.out.println("written is over in file"+filename);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	try {
		DataInputStream dis=new DataInputStream(new FileInputStream(filename));
		int a= dis.readInt();
		boolean b=dis.readBoolean();
		double d=dis.readDouble();
		
		System.out.println("read file "+filename);
		System.out.println(a+" "+b+" "+d);
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
