package question4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class Appendfile {

	public static void main(String[] args) {
		String filename = "Test1.txt";
		filewriter(filename);
		readFile(filename);

	}

	private static void filewriter(String filename) {
		Scanner sc = new Scanner(System.in);
		BufferedWriter bw = null;

		try {
			FileWriter fw = new FileWriter(filename, true);
			bw = new BufferedWriter(fw);
			String input;
			System.out.println("enter a string to append to file");

			while (true) {
				input = sc.nextLine();
				if (input.equalsIgnoreCase("exit")) {
					break;
				}
				bw.write(input);
				bw.newLine();
			}
			System.out.println("file written over");
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}

	}

	private static void readFile(String filename) {
		try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
			System.out.println("Reading from file:");
			String line;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}