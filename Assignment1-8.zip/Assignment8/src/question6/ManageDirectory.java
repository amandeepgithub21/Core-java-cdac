package question6;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ManageDirectory {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        System.out.print("Enter the directory path to list files: ");
        String directoryPath = scanner.nextLine();
        File directory = new File(directoryPath);

        if (directory.exists() && directory.isDirectory()) {
            System.out.println("Files in directory:");
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    System.out.println(file.getName());
                }
            } else {
                System.out.println("No files found in the directory.");
            }
        } else {
            System.out.println("Invalid directory path.");
            return;
        }

        System.out.print("Enter the name for the new directory: ");
        String newDirName = scanner.nextLine();
        File newDirectory = new File(directoryPath, newDirName);

        if (newDirectory.mkdir()) {
            System.out.println("Directory created: " + newDirectory.getAbsolutePath());
        } else {
            System.out.println("Failed to create directory. It may already exist.");
        }

        System.out.print("Enter the name of the file to move (with path if necessary): ");
        String fileNameToMove = scanner.nextLine();
        File fileToMove = new File(fileNameToMove);

        if (fileToMove.exists()) {
            try {
                Files.move(fileToMove.toPath(), Paths.get(newDirectory.getAbsolutePath(), fileToMove.getName()));
                System.out.println("File moved successfully.");
            } catch (IOException e) {
                System.out.println("Failed to move file: " + e.getMessage());
            }
        } else {
            System.out.println("File does not exist.");
        }

        
        System.out.print("Enter the name of the new file to create (in the new directory): ");
        String newFileName = scanner.nextLine();
        File newFile = new File(newDirectory, newFileName);

        try {
            if (newFile.createNewFile()) {
                System.out.println("File created: " + newFile.getAbsolutePath());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("Error creating file: " + e.getMessage());
        }

        
        System.out.print("Enter the name of the file to rename (with path if necessary): ");
        String fileToRenameName = scanner.nextLine();
        File fileToRename = new File(fileToRenameName);

        if (fileToRename.exists()) {
            System.out.print("Enter the new name for the file: ");
            String newFileNameForRename = scanner.nextLine();
            File renamedFile = new File(fileToRename.getParent(), newFileNameForRename);

            if (fileToRename.renameTo(renamedFile)) {
                System.out.println("File renamed to: " + renamedFile.getAbsolutePath());
            } else {
                System.out.println("Failed to rename file.");
            }
        } else {
            System.out.println("File does not exist.");
        }

        System.out.print("Enter the name of the file to delete (with path if necessary): ");
        String fileToDeleteName = scanner.nextLine();
        File fileToDelete = new File(fileToDeleteName);

        if (fileToDelete.exists()) {
            if (fileToDelete.delete()) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("Failed to delete file.");
            }
        } else {
            System.out.println("File does not exist.");
        }

        
        scanner.close();
    }
}
