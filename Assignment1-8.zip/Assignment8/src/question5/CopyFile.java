package question5;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class CopyFile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

              System.out.print("Enter the source file name (with path if not in current directory): ");
        String sourceFileName = scanner.nextLine();

        System.out.print("Enter the destination file name (with path if desired): ");
        String destinationFileName = scanner.nextLine();

        
        Path sourcePath = Paths.get(sourceFileName);
        Path destinationPath = Paths.get(destinationFileName);

        try {
           
            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied successfully!");
        } catch (IOException e) {
          
            if (e instanceof java.nio.file.NoSuchFileException) {
                System.out.println("Error: Source file not found.");
            } else {
                System.out.println("An error occurred: " + e.getMessage());
            }
        } finally {
            
            scanner.close();
        }
    }
}
