package question2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainPerson {
	
	static List<Person> persons=new ArrayList<Person>();
	static ObjectReadWrite obj=new ObjectReadWrite();
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) throws IOException,ClassNotFoundException {
		int ch;
		do
		{
		System.out.println("enter 1 for add person");
		System.out.println("enter 2 for save person");
		System.out.println("enter 3 for load person");
		System.out.println("enter 4 for display person ");
		System.out.println("enter 5 for search person");
		System.out.println("enter 6 for exit");
		System.out.println("enter choice ");
		ch=sc.nextInt();
		try{switch (ch) {
		case 1:
			
			addperson();
             break;
		case 2:
			saveperson();
			break;
		case 3:
			loadperson();
			break;
		case 4:
			display();
			break;
		case 5:
			searchperson();
			break;
		case 6:
			System.out.println("exit ");
			break;
		default:
			System.out.println("invalid input");
			
		}
		}
		catch (Exception e)
		{
			System.out.println("something is wrong");
		}
		}while(ch!=6);
		
	}

	private static void addperson() {
		try {
			System.out.println("enter name: ");
			String name=sc.next();
			System.out.println("enter age: ");
			int age =sc.nextInt();
			System.out.println("enter email: ");
			String email=sc.next();
			
			persons.add(new Person(name, age, email));
			System.out.println("person added sucessfully");
		} catch (Exception e) {
			System.out.println("wrong input");
		}		
	}
	
	private static void saveperson() throws IOException {
		System.out.println("enter file name where to save");
		String filename=sc.next();
		
		obj.writeperson(persons, filename);
		System.out.println("saved person in:"+filename);
	}
	
	private static void loadperson() throws ClassNotFoundException, IOException   {
		System.out.println("enter file name  from where to load");
		String filename=sc.next();
		obj.readperson(filename);
		System.out.println("person loaded from: "+filename);
		
	}
	private static void display() {
		System.out.println("persone in file ");
		obj.displayperson(persons);
	}
	private static void searchperson() {
		System.out.println("enter person name");
		String pname=sc.next();
		
		obj.searchPerson(persons, pname);
	}
}
