package question2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.List;

public class ObjectReadWrite {
	

public void writeperson(List<Person> persons ,String filename)  {

	try {
		FileOutputStream fos=new FileOutputStream(filename);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		
		oos.writeObject(persons);
		
		fos.close();
		oos.close();
		System.out.println("person object has been written in file using java");
	} catch (IOException e) {
	
		System.out.println("error in saving file"+e.getMessage());
	}
	
}

public List<Person>  readperson(String filename)  {
	List<Person> persons=null;
	
	try {
		FileInputStream fis=new FileInputStream(filename);

		ObjectInputStream ois=new ObjectInputStream(fis);

		persons=(List<Person>) ois.readObject();
	} catch (ClassNotFoundException | IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	return persons;
	
}

public void displayperson(List<Person> persons) {
	if(persons ==null || persons.equals(null)) {
		
		System.out.println("no person to display");
	}
	else
	{
		for(Person person :persons) {
			
			person.printperson();
		}
	}
}

public void searchPerson(List<Person> persons,String name) {
	
	for (Person person : persons) {
		if (person.getName().equals(name)) {
			person.printperson();
		} else {
System.out.println("not found");
		}
	}
	
}
}
