package question2;


import java.io.Serializable;

public class Person implements Serializable{

	String name;

	int age;

	String email;
	public Person(String name, int age, String email) {
		
		this.name = name;
		this.age = age;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	void printperson() {
		System.out.println(" Name: "+getName()+" Age: "+getAge()+" Email: "+getEmail());
	}
	
	
	
}
