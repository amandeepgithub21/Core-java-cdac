 package question1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadWriteStrings {
    public static void main(String[] args) throws IOException {

		
		  FileWriter write=new FileWriter("amanfile");
		  
		  write.write("hello i am writing in file using java"); write.close();
		  System.out.println("file written is over"+"\n");
		 
    	
    	FileReader fr=new FileReader("amanfile");
    	String line;
    	BufferedReader bf=new BufferedReader(fr);
    	System.out.println("below line is read by file buffer redaer"+"\n");
    	
    	while((line= bf.readLine())!=null ) {
    		System.out.println(line);
    	}
    }      
    
    
}
