package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcExample 
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		//load the driver
		
	  Class.forName("com.mysql.cj.jdbc.Driver");

	    //get connection
	  Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/astha","root","Astha@811");
	    
	  System.out.println("welcome to jdbc connection");
	 
	    Statement smt = con.createStatement();
	    
	    String query = "select * from emp";
	    
	      ResultSet rs= smt.executeQuery(query);
	      
	      while(rs.next())
	      {
	    	 System.out.println(rs.getInt(1) +"  "+ rs.getString(2));
	      }
	      rs.close();
	      con.close();
		
	}
	
	
	
}
