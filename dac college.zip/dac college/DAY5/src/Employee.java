import java.util.Scanner;

public class Employee 
{

	int empid;
	String name;
	float sal;
	
	Employee()
	{
		System.out.println("default ");
		Scanner s = new Scanner(System.in);
		empid = s.nextInt();
		name = s.next();
		sal = s.nextFloat();
	}
	
	Employee(int id,String na,float sa)
	{  
		System.out.println("parameter");
		 empid=id;;
		 name=na;
		 sal=sa;
		
	}
	void displayEmployee()
	{
		System.out.println(empid);
		System.out.println(name);
		System.out.println(sal);
	}
	
	
}

class TestEmp
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		    Employee e1 = new Employee(s.nextInt(),s.next(),s.nextFloat());
			e1.displayEmployee();
			Employee e2 = new Employee(s.nextInt(),s.next(),s.nextFloat());
			e2.displayEmployee();
			Employee e3 = new Employee();
			e3.displayEmployee();
			
	//default constructor
			
//		Employee e1 = new Employee();
//		e1.displayEmployee();
//		Employee e2 = new Employee();
//		e2.displayEmployee();
	}
	
}

