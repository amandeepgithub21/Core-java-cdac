import java.util.Scanner;

public class Emp 
{

	int eid;
	String name;
	float sal;
	
	public Emp(int eid, String name, float sal)
	{
		this.eid = eid;
		this.name = name;
		this.sal = sal;
	}
	
	
	void dispEmp()
	{
	  System.out.println(eid+name+sal);	
	}
	
		
}



