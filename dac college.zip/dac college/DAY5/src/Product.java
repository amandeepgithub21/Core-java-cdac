
public class Product 
{

	int pid;
	String pname;
	float price;
	
	
	
	Product(int pid,String pname,float price)
	{
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.dispProduct();
	}
	
	void dispProduct()
	{
		System.out.println(pid+pname+price);
	}
	
	
}

class TestProduct
{
	public static void main(String[] args) 
	{
		Product p1= new Product(1001,"HP",800000);
		
	//	p1.dispProduct();
       Product p2= new Product(1002,"DELL",900000);
		
	//	p2.dispProduct();
		
	}
}
