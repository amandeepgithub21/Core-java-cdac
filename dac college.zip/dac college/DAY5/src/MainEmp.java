
public class MainEmp 
{

	public static void main(String[] args) 
	{
		EmpManagement em = new EmpManagement();
		
		
		
		Emp[] e=em.createEmpArray();
		em.displayEmp(e);

     	em.deleteEmp(e);
     	em.displayEmp(e);
     	
//		em.updateEmp();
		
		
	}
	
}
