import java.util.Scanner;

public class EmpManagement
{

	public Emp[] createEmpArray() 
	{
       System.out.println("inside the create array");      
       
       Emp[] e = new Emp[3];
       Scanner s = new Scanner(System.in);
       for(int i =0;i<e.length;i++)
       {
    	   e[i]=new Emp(s.nextInt(),s.next(),s.nextFloat());
       }
       
       return e;
       	
	}

	public void displayEmp(Emp[] e) 
	{
	   System.out.println("display emp");
	   
	   for(int i =0;i<e.length;i++)
       {
		    if(e[i]!=null)
		    {
    	   e[i].dispEmp();
		    }
       }
	   
	}

	public void deleteEmp(Emp[] e)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("empid to delete");
		int no = s.nextInt();
		
		 for(int i =0;i<e.length;i++)
	       {
	    	   if(e[i].eid == no)
	    		   e[i] = null;
	       }
		
		
		
		
	}

	

	
	
	
	
}
