
public class staticNonStatic 
{

	 static int n;
	
	
	static void increment()
	{
		n++;
			
	}
	
	static void dispN()
	{
		System.out.println(n);
	}
	
	public static void main(String[] args) 
	{
		
		staticNonStatic s1 = new staticNonStatic();
		s1.increment();
		s1.dispN();
		staticNonStatic s2= new staticNonStatic();
		s2.increment();
		s2.dispN();
		
		staticNonStatic s3= new staticNonStatic();
	    s3.increment();
		s3.dispN();
		
	}
	
	
	
	
}
