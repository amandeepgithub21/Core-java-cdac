
public class Student 
{
      int id;
      String name;
      int mark;
      static String cname;
      
      Student(int id,String name,int mark) 
      {
    	  this.id = id;
    	  this.name= name;
    	  this.mark = mark;
    	  
    			  
      }
      
      static void changecname()
      {
    	  
    	  cname = "DAC";
      }
	
      void displayStudent()
      {
    	  System.out.println(id+name+mark+cname);
      }
      
      
}

class testStudent
{
	
	public static void main(String[] args) 
	{
		Student.changecname();
		
		Student s1 = new Student(1001,"shan",40);
		
		s1.displayStudent();
		Student s2 = new Student(1002,"raj",50);
		s2.displayStudent();
		Student.changecname();
		Student s100 = new Student(1100,"siju",60);
		s100.displayStudent();
		
		
		Student s101 = new Student(1100,"siju",60);
		s101.displayStudent();
		
	}
	
	
}
