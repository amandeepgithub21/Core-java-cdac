import java.util.Scanner;

public class Student
{

	private int id;
	private String name;
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
	
//	public void display()
//	{
//		System.out.println(id+name);
//	}
//		
//	public void readstudent()
//	{
//		Scanner s = new Scanner(System.in);
//		id = s.nextInt();
//		name = s.next();
//	}
	
}
