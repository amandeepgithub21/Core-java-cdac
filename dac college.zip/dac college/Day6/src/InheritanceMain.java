class Bank
{
	int aid;
	String aname;
	float balance;
	public Bank(int aid, String aname, float balance)
	{
		this.aid = aid;
		this.aname = aname;
		this.balance = balance;
	}
	
	void dispBankDetails()
	{
		System.out.print(aid+aname+balance+ " ");
	}
	
	void withdraw(int amt)
	{
		balance =balance -amt;
		System.out.println(balance);
	}
	
}

class Savings extends Bank
{      float ri;
	
	   Savings(int aid,String aname,float balance,float ri)
	   {
		       super(aid,aname,balance);
		       this.ri = ri;
	   }
	
	 void printsavingDetails()
	 {
		 super.dispBankDetails();
		 System.out.println(ri);
	 }
	   
	   void findInterest()
	   {
		   float interest = balance*ri;
		   System.out.println(interest);
	   }
	
	
}

class Current extends Bank
{
	int overduefees;
	
 public Current(int aid, String aname, float balance,int overduefees) 
 {	 
 super(aid, aname, balance);
		this.overduefees = overduefees;
	}


	void printCurrentDetails()
	{
		super.dispBankDetails();
		System.out.println(overduefees);
	}
	   
	   
	   void findoverdraft(int amt)
	   {
		   if(balance<amt)
			   balance= balance-500;
		   System.out.println(balance);
	   }
}

public class InheritanceMain 
{

	public static void main(String[] args) 
	{
		Savings s = new Savings(1001,"nsnathan",40000,0.02f);
		
		s.printsavingDetails();
		s.withdraw(2000);
		s.findInterest();
		System.out.println("-------------------------");
		Current c = new Current(2001,"shan",20000,500);
		c.printCurrentDetails();
		c.findoverdraft(3000);
		
		
		
	}
	
	
}
