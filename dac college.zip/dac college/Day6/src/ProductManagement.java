import java.util.Scanner;

public class ProductManagement 
{

	void printProductArray(Product[] p)
	{
		for(int i=0;i<p.length;i++)
	    {
	    	p[i].displayProduct();
	    	
	    }
	}	
	
	Product[]  createProductArray()
		{
		Product[] p = new Product[3];
		
		Scanner s = new Scanner(System.in);
		
		for(int i=0;i<p.length;i++)
	    {
			 p[i] = new Product(s.nextInt(),s.next(),s.nextFloat());
	    	
	    }
		
		
	    
	    return p;
		
		}

	public void findtotal(Product[] p)
	{
		for(int i=0;i<p.length;i++)
	    {
			Product.totprice = Product.totprice+ p[i].price;
	    	
	    }
		System.out.println("total product price "+ Product.totprice);
		
	}
		
	}
	
	

