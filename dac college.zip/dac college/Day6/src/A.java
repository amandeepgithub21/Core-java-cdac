
public class A 
{
    int a;
    
    void printA()
    {
    	System.out.println("A class method "+a);
    }
	
}
 class B extends A
{
    int b;
    
    void printB()
    {
    	System.out.println("B class method "+b);
    }
	
}
 
 class C extends B
 {
     int c;
    
     
     void printC()
     {
     	System.out.println("B class method "+c);
     }
     
 }
 
 
 class Testinheritance
 {

	 public static void main(String[] args) 
	 {
	
//		 B b = new B();
//		 b.b = 20;
//		 b.printB();
//		 
//		 b.a = 10;
//		 b.printA();
		 
		 C c = new C();
		 c.a = 10;
		 c.b = 20;
		 c.c = 30;
		 
		 c.printA();
		 c.printB();
		 c.printC();
		 
		 
	}
 }
 
 
 