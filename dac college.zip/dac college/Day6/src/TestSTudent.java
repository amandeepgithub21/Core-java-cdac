
public class TestSTudent 
{

	public static void main(String[] args) 
	{
	
		Student s = new Student();
		s.setId(1001);
		s.setName("nathan");
		
		System.out.println(s.getId() +" "+ s.getName()) ;
		
	}
}
