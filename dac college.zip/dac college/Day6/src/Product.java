
public class Product
{

	int pid;
	String pname;
	float price;
	static float totprice;
	
	public Product(int pid, String pname, float price) {
		
		this.pid = pid;
		this.pname = pname;
		this.price = price;
	}
	
	 void displayProduct()
	{
		System.out.println(pid+pname+price);
	}
	
	
	
}
