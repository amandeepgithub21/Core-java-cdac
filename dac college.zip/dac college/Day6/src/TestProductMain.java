
public class TestProductMain
{

	public static void main(String[] args) 
	{		
		
		ProductManagement pm = new ProductManagement();
		  
	    Product[] p=pm.createProductArray();
	    
	    pm.printProductArray(p);
	    
	    pm.findtotal(p);
	    
	    
	    
	    
	    
	}
	
}
