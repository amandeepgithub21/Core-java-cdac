
public class Arithmetic 
{

	public static void add(int i, int j)
	{
	System.out.println(i+j);	
		
	}

	public static void add(float i, float j)
	{
	System.out.println(i+j);	
		
	}
	
	public static void add(String s1, String s2)
	{
	System.out.println(s1+s2);	
		
	}
	public static void add()
	{
	System.out.println("no parameter");	
		
	}
	
	
}
