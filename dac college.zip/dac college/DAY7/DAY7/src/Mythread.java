
public class Mythread extends Thread
{

	
	public void run()
	{
		System.out.println("Thread running");
		try {
			
			
			for(int i=0;i<10;i++)
			{
				System.out.println(i);
				Thread.sleep(500);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	public static void main(String[] args) 
	{
	
		
		Mythread t1 = new Mythread();
		t1.start();
		
		System.out.println("main ended");
		
	}
	
}
