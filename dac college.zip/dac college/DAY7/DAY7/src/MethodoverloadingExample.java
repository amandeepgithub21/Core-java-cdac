import java.util.Arrays;

public class MethodoverloadingExample
{

	public static void main(String[] args) 
	{
	
		Arithmetic.add();
		
		String[] name = {"nathan","shan","aravi"};
		int[] num = {20,40,10,30};
		
		for(int i=0;i<num.length;i++)
		{
			System.out.println(num[i]);
		}
		
		System.out.println("after sorting");
		
		Arrays.sort(num);
		
		for(int i=0;i<num.length;i++)
		{
			System.out.println(num[i]);
		}
		
		
		System.out.println("sorting of string");
		
		Arrays.sort(name);
		
		for(int i=0;i<name.length;i++)
		{
			System.out.println(name[i]);
		}
		
		
        
		
		
		
		
	}
	
	
	
	
}
