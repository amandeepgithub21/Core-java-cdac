
public class StudentNew 
{

	int id;
	String name;
	
	public StudentNew(int id, String name) {
		
		this.id = id;
		this.name = name;
	}
	
	@Override
	public String toString()
	{
		return "StudentNew [id=" + id + ", name=" + name + "]";
	}

	
	
	public static void main(String[] args) 
	{
		StudentNew s = new StudentNew(101,"raj");
		System.out.println(s.toString());
	}
	
}
