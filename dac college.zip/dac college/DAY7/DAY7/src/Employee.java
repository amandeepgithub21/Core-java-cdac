
public class Employee 
{

	float bsal=1000;
	
	void findSalary()
	{
		System.out.println(bsal);
	}
	
	
}

class permanentEmp extends Employee
{
	
	void findSalary()
	{
		int bonus =100;
		System.out.println(bsal+bonus);
	}
	
	
}


class contract extends Employee
{
	
	void findSalary()
	{
		int noofdays =2;
		System.out.println(bsal*noofdays);
	}
	
}

class overridingMain
{
	public static void main(String[] args) 
	{
		permanentEmp p = new permanentEmp();
		p.findSalary();
		contract c = new contract();
		c.findSalary();
		
		
	}
}