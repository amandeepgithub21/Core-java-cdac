
public class TestInheritance

{

	public static void main(String[] args) 
	{
		Student s = new Student(1001,"nsnathan","Blr",30);
		System.out.println("student");
		s.dispDetails();
		s.dispmark();
		s.findResult();
		System.out.println();
		System.out.println("Teacher");
		Teacher t = new Teacher(2001,"shan","pune",40000);
		t.dispDetails();
		t.printsal();
		t.findTax();
		
		
		
	}
}
