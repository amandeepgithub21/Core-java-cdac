
public class Student extends Person
{

	    
	
	   int mark;
	   
	   Student(int id,String name,String add,int mark)
	   {    super(id,name,add);
		   this.mark = mark;
	   }
	   
	   void dispmark()
	   {
		   System.out.print(mark);
	   }
	   void findResult()
	   {
		   if(mark>16)
			   System.out.print("pass");
		   else
			   System.out.print("fail");
		   
	   }
	   
}
