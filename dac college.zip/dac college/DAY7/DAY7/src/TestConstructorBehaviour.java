class A
{
	 int a;
	 
	 A()
	 {
		  
		 System.out.println("Default construct of class A");
	 }
	 A(int a)
	 {  
		 System.out.println("Parameter construct of class A");
		 this.a = a;
	 }
	void dispA()
	{
		System.out.println(a);
	}
}
class B extends A
{
	int b;
	
	B()
	 {
		 System.out.println("Default construct of class B");
	 }
	 B(int b,int a)
	 
	 {  
		 super(a);
		 
	 System.out.println("Parameter construct of class B");
		 this.b = b;
	 }
	void dispB()
	{
		System.out.println(b);
	}
}



public class TestConstructorBehaviour
{

	public static void main(String[] args) 
	{
		B b = new B(10,30);
		
		b.dispA();
		b.dispB();
		
		
	}
}
