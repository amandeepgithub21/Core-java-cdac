
public class Teacher extends Person
{
	      int sal;
        public Teacher(int id, String name, String add,int sal) 
        {
		super(id, name, add);
		this.sal = sal;
		
	}

      void printsal()
      {
    	  System.out.print(sal);
      }
        
        void findTax()
        {
        	if(sal>500000)
        		System.out.print((sal*0.02f));
        	else
        		System.out.print(sal*0.01f);
        	
        }
	
	
}
