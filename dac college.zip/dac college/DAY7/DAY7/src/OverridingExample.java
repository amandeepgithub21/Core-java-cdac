
class A1
{
	 int a;
	void print(String name)
	{
		System.out.println("Welcome A1 "+name);
	}
	
}

class B1 extends A1
{
	
	void print(String name)
	{    super.print("nsnathan");
		System.out.println("Welcome B1 "+name);
	}
	
}

public class OverridingExample
{

	public static void main(String[] args) 
	{
	
		
		B1 b = new B1();
		b.print("shan");
				
	}
	
	
}
