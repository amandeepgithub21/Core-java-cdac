
public class FindArea 
{

	public static int AreaRectangle(int l,int b)
	{
		int area;
		area = l*b;
		return area;
		
	}
	
	public static int AreaSquare(int a)
	{
		int area;
		area = a*a;
		return area;
		
	}
}
