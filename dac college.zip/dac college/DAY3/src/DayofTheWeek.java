import java.util.Scanner;

public class DayofTheWeek 
{

	public static void main(String[] args) 
	{
	
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the valu of ch");
		int ch = sc.nextInt();
		
		switch(ch)
		{
			
		case 1:System.out.println("Monday");
		break;
		case 2:System.out.println("Tuesday");
		break;
		case 3:System.out.println("Wednesday");
		case 4:System.out.println("Sunday");
		default :System.out.println("Invalid input");
		}
		
		System.out.println("end of main");
		
	}
	
	
}
