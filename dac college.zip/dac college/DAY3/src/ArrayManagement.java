
public class ArrayManagement 
{

	public static void displayArrayElement(int[] mark) 
	{
	
		System.out.println("display array element");
		
		for(int i =0;i<mark.length;i++)
		{

		  System.out.println(mark[i]);
		}
		
		
	}

	public static void findmaxelement(int[] mark) 
	{
		int min=mark[0];
		
		for(int i =0;i<mark.length;i++)
		{
              if(mark[i]<min)
            	  min = mark[i];
		  
		}
		System.out.println("min element is  "+min);
		
	}

	

	
	
	
}
