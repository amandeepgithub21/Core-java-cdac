import java.util.Scanner;

public class FindSumofNumbers 
{

	public static int findSum(int n,Scanner s) {
		
		int total =0;
		for(int i = 0;i<n;i++)
		{
			System.out.println("enter the mark");
			int mark = s.nextInt();
			total = total +mark;
			
		}
		
		return total;
	}
	
	
	
	public static void main(String[] args) 
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the no of subject");
		int no = sc.nextInt();
		
		int total =findSum(no,sc);
		System.out.println("total mark of "+ " "+ no +" subject  "+total);
		System.out.println("end of main");
		
		
		
		
		
	}

	
	
}
