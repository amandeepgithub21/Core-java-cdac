
public class TypecastingExample 
{

	public static void main(String[] args) 
	{
	
//		int i = 20;
//		float f = i;
		
//		int i; 
//		float f = 20.4f;
//		i = (int) f;
		
		//System.out.println(i);
		
//		char ch = 'A';
//		
//		int i;
//		
//		i = ch;
//		
//		System.out.println(i);
		
		
		int i = 65;
		char ch;
		ch = (char) i;
		System.out.println(ch);
				
		
		
		
		
	}
	
}
