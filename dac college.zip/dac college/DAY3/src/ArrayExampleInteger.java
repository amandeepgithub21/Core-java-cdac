
public class ArrayExampleInteger 
{

	public static void main(String[] args) 
	{
	

		//int[]  mark = new int[5];

		//	mark[0]= 10;
		//	mark[1]=20;
		//	mark[2]=40;
		//	mark[3]=50;
		//	mark[4]=30;
//	
		int[] mark= {10,20,30,40,50};

	
	for(int i =0;i<mark.length;i++)
	{

	  System.out.println(mark[i]);
	}
	
	
	
	//using enhanced for loop
	
//	for(int ele :mark)
//	{
//		System.out.println(ele);
//	}
		
	}
	
	
	
}
