import java.util.Scanner;

public class WhileExample 
{

	public static void main(String[] args)
	{
	
		int no,rev = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the no ");
		 no = sc.nextInt();//456
		
//		 while(no>0)
//		 {
//			 
//			 rev = no%10;
//			 no = no/10;
//			System.out.print(rev); 
//			
//			 
//		 }
		 
	
		 do
		 {
			 
			 rev = no%10;
			 no = no/10;
			System.out.print(rev); 
			
			 
		 }while(no>0); 
		 
		 
		 
		 
		
	}
	
}
