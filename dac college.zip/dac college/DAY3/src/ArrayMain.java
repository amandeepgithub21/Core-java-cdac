
public class ArrayMain
{

	public static void main(String[] args) 
	{
	
		int[] mark= {50,20,30,10,40};
		
		ArrayManagement.displayArrayElement(mark);
		ArrayManagement.findmaxelement(mark);
		
	} 
	
	
	
}
