
public class FindAreaMain 
{

	public static void main(String[] args) 
	{
	     int l = 10;
	     int b = 20;
	     int a = 4;
		int areaR =FindArea.AreaRectangle(l,b);
		int areaS = FindArea.AreaSquare(a);
		System.out.println("Area of Rectangle is = "+areaR);
		System.out.println("Area of Rectangle is = "+areaS);
			}
}
