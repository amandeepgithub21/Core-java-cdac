

public class StringArrayExample 
{

	public static void main(String[] args) 
	{
	

		
		String[] subject = {"c++","java","python","DBT"};
		
		
		int a = 10;
		
		int b = a;
		
		                   
		for( String ele   :subject)
		{
			System.out.println(ele);
		}
		
		
		
	}
	
}
