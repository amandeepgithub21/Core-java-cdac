package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementExample 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
		//System.out.println("got the jdbc connection");
		Class.forName("com.mysql.cj.jdbc.Driver");
		
	Connection con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/astha","root","Astha@811");
	   System.out.println("got the jdbc connection");
	
	         Statement smt=con.createStatement();    
		
		   String query = "select * from emp";
		   ResultSet rs=smt.executeQuery(query);
		   
		   while(rs.next())
		   {
			 System.out.println(rs.getInt("EMPCODE")+ " "+ rs.getString(2)+ " "+rs.getInt(11));
			   
		   }
		   
		 
		rs.close();
		con.close();
		
	}
	
}
