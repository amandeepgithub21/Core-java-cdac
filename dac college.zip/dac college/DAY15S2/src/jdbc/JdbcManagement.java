package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcManagement
{

	public Connection createConnection() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/astha","root","Astha@811");
		   System.out.println("got the jdbc connection");
		   
		   return con;
	}
	
	
	
}
