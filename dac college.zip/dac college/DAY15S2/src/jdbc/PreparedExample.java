package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PreparedExample
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		//System.out.println("got the jdbc connection");
				Class.forName("com.mysql.cj.jdbc.Driver");
				
			Connection con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/astha","root","Astha@811");
			   System.out.println("got the jdbc connection");
	            
			   PreparedStatement pmt;
			   String query;
			   // RETRIVE
			   
			    query ="select * from emp where deptcode = ?";
					   
					   
			   pmt=con.prepareStatement(query);
			   
			   Scanner s = new Scanner(System.in);
			   System.out.println("enter the deptno");
			   String  code = s.next();
			   
			   pmt.setString(1, code);
			   
			   ResultSet rs=pmt.executeQuery();
			   
			   while(rs.next())
			   {
				 System.out.println(rs.getInt("EMPCODE")+ " "+ rs.getString(2)+ " "+rs.getString("deptcode")+" " + rs.getInt("basicpay"));
				   
			   }
			   
			 
			   //UPDATE
			   
			   query = "update emp set basicpay = ? where empcode = ?";
			   
			   pmt=con.prepareStatement(query);
			   
			   System.out.println("enter the empcode");
			   int  empcode = s.nextInt();
			   System.out.println("enter the basicpapy");
			   int sal = s.nextInt();
			   pmt.setInt(1, sal);
			   pmt.setInt(2, empcode);
			   
			   
			   int nrec =pmt.executeUpdate();
			   
			   System.out.println(nrec + " record updated");
			rs.close();
			con.close();
			   
			JdbcManagement jm = new JdbcManagement();
			   Connection con =jm.createConnection();
			   
	}
	
}
