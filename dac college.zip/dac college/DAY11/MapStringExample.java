import java.util.HashMap;
import java.util.Map;

public class MapStringExample 
{

	public static void main(String[] args) 
	{
	
	HashMap<Integer , String > hm = new HashMap<>();
		
		
	hm.put(1, "cdac blr dac ");
	hm.put(2, "cdac pune dac");
	hm.put(3, "cdac blr dbda");
	hm.put(4, "cdac pune dbda");
	hm.put(5, "cdac Hyd dac");
	
	
	
	for( Map.Entry<Integer, String> h:  hm.entrySet())
	{
		System.out.println(h.getKey() + " "+h.getValue());
		
	}
	
	
	
		
	}
	
}
