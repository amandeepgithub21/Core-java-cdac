import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashMapStudentObject 
{

	public static void main(String[] args) 
	{
	
	HashMap<Integer,Student> hm=new HashMap<>();
	Student s1=new Student(123,"Laya",45);
	Student s2=new Student(124,"Steve",40);
	Student s3=new Student(125,"Raj",45);
	hm.put(1,s1);
	hm.put(2,s2);
	hm.put(3,s3);
	Student s;
	for(Map.Entry<Integer, Student>h :hm.entrySet())
	{
		
		System.out.print(h.getKey()+ " ");
		
		 s= h.getValue();
		s.display();
		
		
	}
	
	
	System.out.println("enter the key");
	Scanner sc = new Scanner(System.in);
	int k = sc.nextInt();
	
	hm.remove(k);
	System.out.println("object removed");
	
	for(Map.Entry<Integer, Student>h :hm.entrySet())
	{
		
		System.out.print(h.getKey()+ " ");
		
		 s = h.getValue();
		s.display();
		
		
	}
	
	
	
	System.out.println("enter the id");
	 
      k = sc.nextInt();
	int key = 0;
      for(Map.Entry<Integer, Student>h :hm.entrySet())
  	{
  		
    	 Student obj = h.getValue();
    	 
  		if(obj.id ==k)
  		{
  		
  			 key =h.getKey();
  			
  		}
  		
  		
  	}
      hm.remove(key);
      
      
      
	System.out.println("object removed");
	
	for(Map.Entry<Integer, Student>h :hm.entrySet())
	{
		
		System.out.print(h.getKey()+ " ");
		
		 s = h.getValue();
		s.display();
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	
}
