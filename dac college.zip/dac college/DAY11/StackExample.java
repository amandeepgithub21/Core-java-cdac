import java.util.Stack;

public class StackExample 
{

	public static void main(String[] args) 
	{
	
		Stack<Integer> s = new Stack<>();
		
		
//		s.add(10);
//		s.add(20);
//		s.add(30);
//		s.add(40);
//		s.add(50);
		
		
		s.push(20);
		s.push(30);
		s.push(40);
		s.push(10);
		s.push(60);
		
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		
		System.out.println("element poped");
		 Integer  n =s.pop();
		
		System.out.println(n);
		
		
		System.out.println("after pop");
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		
		System.out.println("peek");
		n =s.peek();
		System.out.println(n);
		
		
		System.out.println("after peek");
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		
		
		s.remove(2);
		
		System.out.println("after remove");
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		
		
		s.set(2, 50);
		System.out.println("after update");
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		
		s.add(2,40);
		
		System.out.println("after insert");
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		
	} 
	
	
	
}
