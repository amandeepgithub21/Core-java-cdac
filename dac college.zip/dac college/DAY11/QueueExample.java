import java.util.PriorityQueue;

public class QueueExample 
{

	public static void main(String[] args) 
	{
	
		PriorityQueue<Integer> pq = new PriorityQueue<>();
		
		pq.add(10);
		pq.add(20);
		pq.add(30);
		pq.add(40);
		
		for(Integer ele :pq)
		{
			System.out.println(ele);
		}
		
		
		System.out.println("after poll");
		
		Integer n=pq.poll();
		
		System.out.println(n);
		System.out.println("--------------------");
		for(Integer ele :pq)
		{
			System.out.println(ele);
		}
		
		System.out.println("after peek");
		
		 n=pq.peek();
		
		System.out.println(n);
		System.out.println("--------------------");
		for(Integer ele :pq)
		{
			System.out.println(ele);
		}
		
		
		System.out.println("after remove");
		
boolean rm=		pq.remove(40);
		
		System.out.println(rm);
		System.out.println("--------------------");
		for(Integer ele :pq)
		{
			System.out.println(ele);
		}
		
		
	}
	
	
}
