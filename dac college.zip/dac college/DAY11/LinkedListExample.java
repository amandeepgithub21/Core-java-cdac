import java.util.LinkedList;

public class LinkedListExample 
{

	public static void main(String[] args) 
	{
	
		
		LinkedList<Integer> ll = new LinkedList<>();
		
		
		ll.add(10);
		ll.add(20);
		ll.add(40);
		ll.add(30);
		ll.add(50);
		
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		ll.remove(3);
		
		System.out.println("after remove");
		
		
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		System.out.println("after update");
		ll.set(2, 100);
		
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		System.out.println("after insert");
		ll.add(2, 33);
		
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		
		ll.remove(10);
		
		System.out.println("after remove");
		
		
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		
	}
	
}
