import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapExample 
{

	public static void main(String[] args) 
	{
	
		HashMap<Integer ,Integer > hm = new HashMap<>();
		
		hm.put(1, 10);
		hm.put(1, 20);
		hm.put(3, 30);
		hm.put(4, 40);
		
		Set<Entry<Integer, Integer>> s= hm.entrySet();
		
		//Arraylist<Employee> e= em.createOBject();
		
		
		
		
		for(Map.Entry<Integer, Integer> h: s )
		{
			System.out.println(h.getKey() + " "+ h.getValue());
			
			
		}
		
		System.out.println("after given the key value 2");
		Integer value =hm.get(2);
     
		System.out.println(value);
		
		
		System.out.println("after given the key value 1");
		hm.remove(1);
     

		for(Map.Entry<Integer, Integer> h:  hm.entrySet())
		{
			System.out.println(h.getKey() + " "+ h.getValue());
			
			
		}
		
		System.out.println("after update");
		hm.put(3,100);
		
		
		for(Map.Entry<Integer, Integer> h:  hm.entrySet())
		{
			System.out.println(h.getKey() + " "+ h.getValue());
			
			
		}
		
		System.out.println("after insert");
		
	hm.put(5, 50);
		
		
	for(Map.Entry<Integer, Integer> h:  hm.entrySet())
	{
		System.out.println(h.getKey() + " "+ h.getValue());
		
		
	}
		
		
		
//		bank
//		
//		
//		return sbi;
//		
//		return icici
//		
//	bank b=createobject()
//		b.payment()
		
	}
	
	
}
