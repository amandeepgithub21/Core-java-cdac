import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client 
{

	public static void main(String[] args) throws UnknownHostException, IOException 
	{
	
		Socket s = new Socket("localhost",559);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the message for the server");
		String cmsg = sc.next();
		
		      OutputStream  os= s.getOutputStream();
		      PrintStream ps = new PrintStream(os);
		       ps.println(cmsg);
		       
		       s.close();
		       os.close();
		       ps.close();
		
	} 
	
	
	
	
}
