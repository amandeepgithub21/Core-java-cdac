import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server 
{

	public static void main(String[] args) throws IOException 
	{		
	
	ServerSocket ss = new ServerSocket(559);	        Socket s = ss.accept();
	
	System.out.println("got connection");
	
	  InputStream is=s.getInputStream();
	  
	  InputStreamReader isr = new InputStreamReader(is);
	  BufferedReader br = new BufferedReader(isr);
	  
	    String cmg =br.readLine();
	    System.out.println("messge received from client "+cmg);
	  
	    ss.close();
	    s.close();
	    br.close();
	    
	    
	  
	  
	  
	   
	   
	   
	   
	   
	   
	
	
	
	}
	
}
