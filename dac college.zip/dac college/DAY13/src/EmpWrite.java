import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class EmpWrite 
{
	
	public static void main(String[] args) throws IOException 
	{
	
//		Employee e1 = new Employee(1001,"shan",3000);
//		Employee e2 = new Employee(1002,"raj",4000);
//		Employee e3 = new Employee(1003,"siju",5000);
		Employee e4 = new Employee(1004,"kumar",5000);
//		ArrayList<Employee>  al = new ArrayList<>();
//		al.add(e1);
//		al.add(e2);
//		al.add(e3);
		
		
		FileOutputStream fs = new FileOutputStream("dac"
		+ true );
		ObjectOutputStream oos = new ObjectOutputStream(fs);
		
//		oos.writeObject(e1);
//		oos.writeObject(e2);
//		oos.writeObject(e3);
		oos.writeObject(e4);
		//oos.writeObject(al);
		
		System.out.println("emp write is over");
		oos.close();
		
		
		
	}
	

}
