
abstract public class Bank 
{

	abstract void payment(float amount);
	
}

class sbi extends Bank
{
	
	void payment(float amount)
	{
		System.out.println("paymet by sib "+ amount);
	}
	
}

class icici extends Bank
{
	
	void payment(float amount)
	{
		System.out.println("paymet by icici "+ amount);
	}
	
}

class testabstraction
{
	
	
	public static void main(String[] args) 
	{
		sbi s = new sbi();
		s.payment(10001);
		
		icici i = new icici();
		i.payment(2000);
		
	}
}
