
public class Employee 
{
    int empno;
    String name;
    float sal;
    Address add;
    
	public Employee(int empno, String name, float sal, Address add) {
	
		this.empno = empno;
		this.name = name;
		this.sal = sal;
		this.add = add;
	}
    
	void dispEmp()
	{
		System.out.print(empno+name+sal+add.city+add.state+add.pin);
		//add.dispAddress();
	}
	
	
	
	public static void main(String[] args) 
	{
		
		Address add = new Address("Bangalore","Karnataka",560038);
		Employee e = new Employee(1001,"shan",30000,add);
		e.dispEmp();
		
		
		
	}
	
}
