import java.util.Scanner;

public class NetBankingPayment
{

	void payment(float amount)
	{
		System.out.println("Processing payment  "+ amount +" via net Baning");
	}
}

class SBI extends NetBankingPayment
{
	void payment(float amount)
	{
		System.out.println("Processing payment  "+ amount + " via SBI");
	}
}


class ICICI extends NetBankingPayment
{
	void payment(float amount)
	{
		System.out.println("Processing payment  "+ amount + " via ICICI");
	}
}

class HDFC extends NetBankingPayment
{
	void payment(float amount)
	{
		System.out.println("Processing payment  "+ amount + " via HDFC");
	}
}


class testRuntimePolymorphism
{
	
	public static NetBankingPayment createbankobject(String bname) 
	{

		if(bname.equals("SBI"))
		{
		
		   return   new SBI();
		   
		
		}
	else if(bname.equals("ICICI"))
	{
		return new ICICI();
		
	}
	
	else if(bname.equals("HDFC"))
	{
		return  new HDFC();
		
	}
	else
		return null;
		
		


		
	}
	
	
	
	
	public static void main(String[] args) 
	{
		
		
		NetBankingPayment n;
	
		
		Scanner s  = new Scanner(System.in);
		System.out.println("enter the bank name to be processed");
		String bname=s.next();
		
		 n =createbankobject(bname);
		 n.payment(1000);
		
		
		
	}

	
	
	
}



