
public class Address
{
	String city;
    String state;
    int pin;
    
	public Address(String city, String state, int pin) {
		
		this.city = city;
		this.state = state;
		this.pin = pin;
	}
    
	void dispAddress()
	{
		System.out.println(city+state+pin);
	}
    
    
}
