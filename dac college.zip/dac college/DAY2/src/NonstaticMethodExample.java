
public class NonstaticMethodExample
{

	    public void findmax()
	    {
	    	System.out.println("inside findmax");
	    }
	
	
	
	public static void main(String[] args) 
	{
		NonstaticMethodExample n = new NonstaticMethodExample();
	    System.out.println("inside main");
		n.findmax();
	}
	
	
}
