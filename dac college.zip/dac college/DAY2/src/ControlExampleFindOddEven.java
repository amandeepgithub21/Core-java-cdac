
public class ControlExampleFindOddEven 
{
// find  the given data is odd or even
	
	public static void main(String[] args) 
	{
	
		int num = 31;
		
		if(num%2 ==0)
			System.out.println("the given number is even");
		else
			System.out.println("the given number is odd");
		
		
	}
	
	
	
}
