
public class FindGrade 
{

	public static void main(String[] args) 
	{
	      int per = 30;
	       
	       if(per>=90)
	    	   System.out.println("A");
	       else if(per>=80 && per<90)
	    	   System.out.println("B");
	       
	       else if(per>=60 && per<80)
	    	   System.out.println("C");
	       else
	    	   System.out.println("D");
		
		
	
		
		
	}
	
	
}
