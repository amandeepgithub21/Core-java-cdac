import java.util.Scanner;

public class ReadDataFromUser
{

	public static char findGrade(int p )
	{
		char grade;
		      
	       if(p>=90)
	    	   grade = 'A';
	       else if(p>=80 && p<90)
	    	   grade = 'B';
	       
	       else if(p>=60 && p<80)
	    	   grade = 'C';
	       else
	    	   grade = 'D';
	       return grade;
	}
	
	
	
	public static void main(String[] args) 
	{
	
		Scanner s =new Scanner(System.in);
		
		System.out.println("enter the percentage");
		int per = s.nextInt();
				
		 char g=findGrade(per);
		System.out.println("grade = "+g);
		
		System.out.println("end of main");
		
		
		//how to read data from the user
		
		/*
		 * Scanner s =new Scanner(System.in);
		 * 
		 * System.out.println("enter the empno"); int empno =s.nextInt();
		 * System.out.println("enter the sal"); float empsal = s.nextFloat();
		 * System.out.println("enter the name"); String name = s.next();
		 * 
		 * System.out.println("empno = "+ empno); System.out.println("empsal = " +
		 * empsal); System.out.println("empname = " + name );
		 */
		
		
		
	}
	
}
