
public class OperatorExample 
{

	public static void main(String[] args) 
	{
	
//		int a = 12;
//		int b = 5;
		
		//arithmetic
		
//		System.out.println(a+b);
//		System.out.println(a-b);
//		System.out.println(a*b);
//		System.out.println(a/b);
//		System.out.println(a%b);
		
//		System.out.println(a + "  " +b);
		
		//relational
		
//		System.out.println(a>b);
//		System.out.println(a<b);
//		System.out.println(a>=b);
//		System.out.println(a<=b);
//		System.out.println(a!=b);
		
		
		//logical && ||
		
//		int lab = 10;
//		int ccee = 20;
//		String result=null;
//	       if(lab>16 && ccee>16)
//	       {
//			 result = "pass";
//	       }else
//	    	   result = "fail";
//		
//	       System.out.println(lab>16 && ccee>16);
//	       System.out.println(lab>16 || ccee>16);
//		System.out.println(result);
//		
		
		//increment and decrement
		
		
		int c = 0;
		
//		System.out.println(c);
//		System.out.println(++c);
//		System.out.println(c++);
//		System.out.println(c);
		
		
		int d = c + c++ + ++c + c;
		
		System.out.println(d);
		
		
		
	}
	
}
