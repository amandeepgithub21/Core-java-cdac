
public class findResult 
{

	public static void main(String[] args) 
	{
	
		int lab = 15;
		int ccee = 20;
		
		if(lab>=16&& ccee>=16)
			System.out.println("pass");
		else
			System.out.println("fail");
		
			
	}
	
}
