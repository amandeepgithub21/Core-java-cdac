import java.util.Scanner;

public class MethodExampleFindMax
{
	public static int findmax(int c,int d) 
	{
		int max=0;
		
		if(c>d)
		    max = c;
		else
			max = d;
		return max;
		
	} 
	
	public static void main(String[] args) 
	{
	
		Scanner s =new Scanner(System.in);
		int a;
		int b;
		a = s.nextInt();
		b = s.nextInt();
		int m=findmax(a,b);
		System.out.println("max "+ m);
		
	}

	
	
	
}
