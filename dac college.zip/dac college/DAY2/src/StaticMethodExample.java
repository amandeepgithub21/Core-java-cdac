
public class StaticMethodExample 
{
public static void findOddEven()
{
	
	System.out.println("inside the oddeven method");
	int num = 30;
	if(num%2==0)
		System.out.println("even");
	else
		System.out.println("odd");

}
	
public static void main(String[] args) 
{
System.out.println("method example");
findOddEven();

}

}
