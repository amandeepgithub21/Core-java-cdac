
public class Adding
{

	public static void main(String[] args) 
	{
	      int num1 = 50;
	      int num2 = 20;
	      int sum = num1 +num2;
	      System.out.println("sum of "+ num1 + " + "+num2+" =" + sum);
	
	      if(num1>num2) {
	    	  System.out.println(num1 + "is greater");
	    	  
	    	  
	    	  
	      }
	      else
	    	  System.out.println(num2 + "is greater");
	}
	
	
}
