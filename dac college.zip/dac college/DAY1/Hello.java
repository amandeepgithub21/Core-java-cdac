
public class Hello 
{

	public static void main(String[] args)
	{
		System.out.println("Welcome");
		int id;
	    String name;
	    String desig;
	    float sal;
	    char grade;
	    Boolean ispromoted;
	  
	   id =1001;
	   name = "nsnathan";
	   desig = "faculty";
	   sal = 30000;
	   grade = 'A';
	   ispromoted = true;


	   System.out.println("employee id " + id);
	   System.out.println("name   " +name);
	   System.out.println("designation  "+desig);
	   System.out.println("grade" +grade);
	   
	   System.out.println("salary " +sal);
	   System.out.println("status" + ispromoted);

		
		
		
		
	}
	
}
