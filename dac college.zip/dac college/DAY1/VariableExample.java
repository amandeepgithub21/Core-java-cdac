class VariableExample
{

public static void main(String[] args)
{

    int id;
    String name;
    String desig;
    float sal;
    char grade;
    Boolean ispromoted;
  
   id =1001;
   name = "nsnathan";
   desig = "faculty";
   sal = 30000;
   grade = 'A';
   ispromoted = true;


   System.out.println("employee id " + id);
   System.out.println("name   " +name);
   System.out.println(desig);
   System.out.println(grade);
   System.out.println(sal);
   System.out.println(ispromoted);





}



}