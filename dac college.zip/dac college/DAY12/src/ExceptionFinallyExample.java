
public class ExceptionFinallyExample
{

	
	public static void main(String[] args) 
	{
	
		String name=null;
		
		try
		{
			
		  int c= 20/0;	
		System.out.println(name.length());
		}catch(ArithmeticException e)
		{
			System.out.println("Arithmetic excpeiton ");
			
		}catch(NullPointerException e)
 
		{
			System.out.println("data is not assignen to variable name ");
			
		}
		
		System.out.println("rest of the main");
		
	} 
	
	
}
