
public class FinallyExample
{

	public static void main(String[] args) 
	{
	
		String name=null;
		
		try
		{
			
		 
		System.out.println(name.length());
		}catch(NullPointerException e)
 
		{
			System.out.println("data is not assigned to variable name ");
			
		}
		finally
		{
			System.out.println("inside the finally resources are closed");
		}
		System.out.println("rest of the main");
		
	} 
	
	
	
	
	
}
