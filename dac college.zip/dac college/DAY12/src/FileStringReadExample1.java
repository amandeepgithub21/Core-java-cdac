import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileStringReadExample1 
{

	
	public static void main(String[] args) throws IOException 
	{
	    FileReader fr = new FileReader("dac");
		BufferedReader br = new BufferedReader(fr);
		
		String str;
		    while((str = br.readLine())!=null)
		    {
		    	System.out.println(str);
		    	
		    }
		
		
		
		
		
//	     String str1 =br.readLine();
//	     String str2 =br.readLine();
//	     System.out.println(str1.length());
//	     System.out.println(str2.length());
//	     System.out.println(str1);
//	     System.out.println(str2);
		
		
		
		
		/*
		 * //read char by char
		 * 
		 * int ch; while((ch= fr.read())!=-1) { System.out.print((char)ch); }
		 */
		
	
		
		
	}
	
	
}
