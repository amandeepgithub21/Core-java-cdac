
public class LessBalance extends Exception
{

	LessBalance(String message)
	{
		super(message);
	}
	
	
}
