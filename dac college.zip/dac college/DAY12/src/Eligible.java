
public class Eligible extends Exception
{
       
     Eligible(String message)
     {
    	 super(message);
     }
     
     
     
}
