import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class FileObjectWrite 
{

	public static void main(String[] args) throws IOException 
	{
	
		Student s1=new Student(123,"Laya",45);
		Student s2=new Student(124,"Steve",40);
		Student s3=new Student(125,"Raj",45);
		
		
		FileOutputStream fos = new FileOutputStream("dac1");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(s1);
		oos.writeObject(s2);
		oos.writeObject(s3);
		
		fos.close();
		oos.close();
		System.out.println("student object has been written in the file");
		
		
		
	}
	
}
