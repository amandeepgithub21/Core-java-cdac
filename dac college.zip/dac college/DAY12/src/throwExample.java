import java.util.Scanner;

public class throwExample
{
	//
	public static void checkEligible(String q)
	{
		  if(q.equals("BE"))
				 System.out.println("eligible");
		  else
		  {
			  try {
			  Eligible e  = new Eligible("not eligible");
			
				throw e;
			} catch (Eligible e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
			}
		  }
				
	}
	
	public static void main(String[] args) 
	{
	
		System.out.println("enter the qualification");
		Scanner s = new Scanner(System.in);
		String q = s.next();
		
		checkEligible(q);
		
		
		
	}

	
	
	
}
