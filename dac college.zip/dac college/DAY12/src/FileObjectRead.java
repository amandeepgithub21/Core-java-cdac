import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class FileObjectRead 
{

	public static void main(String[] args) throws ClassNotFoundException, IOException 
	{
	
		FileInputStream fis = new FileInputStream("dac1");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Student s1 =(Student) ois.readObject();
		s1.display();
		Student s2 =(Student) ois.readObject();
		s2.display();
		Student s3 =(Student) ois.readObject();
		s3.display();
		
		
	}
	
	
}
