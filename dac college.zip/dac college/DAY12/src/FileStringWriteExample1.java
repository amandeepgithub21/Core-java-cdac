import java.io.FileWriter;
import java.io.IOException;

public class FileStringWriteExample1
{

	public static void main(String[] args) throws IOException 
	{
	
		FileWriter fw = new FileWriter("dac");
		
		String str1 = "welcome to java file handling";
		String str2 = "we have session tomorrow";
		String str3 = "will be handling socket programming";
		fw.write(str1+"\n");
		fw.write(str2+"\n");
		fw.write(str3+"\n");
		
		
		System.out.println("file write is over");
		
		fw.close();
		
		
	}
	
	
}
