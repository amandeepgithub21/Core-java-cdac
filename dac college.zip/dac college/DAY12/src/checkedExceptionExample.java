import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class checkedExceptionExample 
{

	public static void main(String[] args) throws FileNotFoundException 
	{
	
		FileInputStream fs = new FileInputStream("dac");
		
		
		
	}
	
	
}
