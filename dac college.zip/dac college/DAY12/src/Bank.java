
public class Bank 
{     
	    int balance = 100;

	public  void checkBalance() throws LessBalance 
	{
		   if(balance>1000)
		   {
			   System.out.println("you can withdraw");
		   }else
		   {
			   
			   throw new LessBalance("less balance");
			}
		   }   
		
	
	
	
	public static void main(String[] args) throws LessBalance 
	{
		Bank b = new Bank();
		
			b.checkBalance();
		
		
			
	}

	
	
}
