
public class EmpDB 
{

	public static void main(String[] args) 
	{
	
	Mysql m  = new Mysql();
	m.connect();
		
	}
}
