import java.util.ArrayList;

public class EmpArryList 
{

	public static void main(String[] args) 
	{
	
		EmpManagement em = new EmpManagement();
		
	    ArrayList<Employee> al	=em.createEmpobject();
		
		em.displayEmpobject(al);
		
		em.deleteEmpobject(al);
	   
		em.displayEmpobject(al);
		
		
		
		
		
		
			
		
			
		
	}
	
}
