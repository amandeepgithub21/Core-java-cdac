
interface dbConnect
{
	
	void connect();
	
}

class Oracle implements dbConnect
{

	@Override
	public void connect() 
	{
		System.out.println("connection Oracle database");
		
	}
	
}

class Mysql implements dbConnect
{

	@Override
	public void connect() 
	{
		System.out.println("connection Mysql database");
		
	}
	
}

