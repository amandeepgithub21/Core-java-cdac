import java.util.ArrayList;
import java.util.Scanner;

public class EmpManagement 
{

	ArrayList<Employee> createEmpobject()
	{
		ArrayList<Employee> al = new ArrayList<>();
		
		Employee e1 = new Employee(1001,"shan",3000);
		Employee e2 = new Employee(1002,"raj",4000);
		Employee e3 = new Employee(1003,"guru",5000);
		al.add(e1);
		al.add(e2);
		al.add(e3);
		return al;
		
	}
	
	void displayEmpobject(ArrayList<Employee> al)
	{
		
		for(Employee e   :al)
		{
		    e.dispEmployee();
		}
		
	}

	public void deleteEmpobject(ArrayList<Employee> al)
	{
		System.out.println("enter the empid to delete");
		Scanner s = new Scanner(System.in);
		int id = s.nextInt();
		int pos =0;
		for(Employee e   :al)
		{
		    
			if(e.eid == id)
			{
				pos = al.indexOf(e);
				
			}
			
			
		}
		al.remove(pos);
		System.out.println("given object is removed");
		
	}
}
