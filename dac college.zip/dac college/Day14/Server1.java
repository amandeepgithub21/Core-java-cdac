import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server1
{

	public static void main(String[] args) throws IOException 
	{
	
		ServerSocket ss = new ServerSocket(222);
		        Socket s=ss.accept();
		System.out.println("got connection");
		
		//read data from socket
		
		InputStream os =s.getInputStream();
		
		InputStreamReader ir = new InputStreamReader(os);
		BufferedReader br = new BufferedReader(ir);
		
		String cmg=br.readLine();
		//Write to the console;
		
		System.out.println("message received from client is "+cmg);
		
		
		//read from console
		
		InputStreamReader ir1 = new InputStreamReader(System.in);
		BufferedReader br1 = new BufferedReader(ir1);
		System.out.println("enter the message for client");
		String smg=br1.readLine();
		
		
		//write to the socket
		
		OutputStream os1 =s.getOutputStream();
	      PrintStream ps = new PrintStream(os1);
	       ps.println(smg);
		ss.close();
		s.close();
		ir.close();
		br.close();
		os.close();
		
		
		
		
		
		
		
	}
}
