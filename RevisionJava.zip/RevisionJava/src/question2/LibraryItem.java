package question2;

class LibraryItem {

	String title, author, itemid;
	boolean isCheckedOut;

	public LibraryItem(String title, String author, String itemid, boolean isCheckedOut) {
		this.title = title;
		this.author = author;
		this.itemid = itemid;
		this.isCheckedOut = isCheckedOut;
	}

	void checkOut() {
		if (isCheckedOut == true) {
			System.out.println("has been cheked out");
		} else {
			System.out.println("is already checked out");
		}
	}

	void returnItem() {
		if (isCheckedOut == false) {
			System.out.println("has been  returend");
		} else {
			System.out.println("was not  checked out");
		}
	}

	void displayDetails() {
		System.out.print(
				"title=" + title + " author=" + author + " itemid=" + itemid);
	
	  System.out.println("Checked Out: " + (isCheckedOut ? "Yes" : "No"));
	}

}