package question2;

public class Book extends LibraryItem{

	String genre ;
	
	public Book(String title, String author, String itemid, boolean isCheckedOut,String genre) {
		super(title, author, itemid, isCheckedOut);
	this.genre=genre;
	
	}
	void displayDetails() {
		super.displayDetails();
		System.out.println(" genre="+genre);
	}

}
