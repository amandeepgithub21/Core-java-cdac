package question2;

public class Magazine extends LibraryItem {
	int issueNumber;

	public Magazine(String title, String author, String itemid, boolean isCheckedOut, int issueNumber) {
		super(title, author, itemid, isCheckedOut);
		this.issueNumber = issueNumber;

	}
	
	void displayDetails() {
	super.displayDetails();
	System.out.println(" issuenumber="+issueNumber);
	}
}
