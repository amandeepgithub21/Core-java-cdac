package question2;

public class Library {

	public static void main(String[] args) {
		LibraryItem lib = new Book("theman", "aman", "12345", false, "genre123");
		LibraryItem lim = new Magazine("God", "deep", "54321", true, 205);

		lib.checkOut();
		lib.returnItem();
		lib.displayDetails();
		System.out.println("blow magzine");
		lim.checkOut();
		lim.returnItem();
		lim.displayDetails();
	}

}
