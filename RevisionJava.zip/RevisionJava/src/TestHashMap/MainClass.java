package TestHashMap;
import java.util.Scanner;

public class MainClass {

public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	StudentManagement sm=new StudentManagement();
	int ch = 0;
	do {
		
	
	System.out.println("enter 1 for add item");
	System.out.println("enter 2 for display");
	System.out.println("enter 3 for update");
	System.out.println("enter 4 for remove item");
	System.out.println("enter 5 for exit");
	ch=sc.nextInt();
	
	 
	switch (ch) {
	case 1: 
		sm.addstudent();
		
		 break;
	case 2: 
		sm.display();
		 break;
	case 3: 
		sm.update();
		 break;
	case 4: 
		sm.delete();
		 break;
	case 5: 
		System.out.println("exit");
		 break;
	
	
	default:
		System.out.println("invalid");
		
		
	}	
	}while (ch!=5);
}
}
