package TestHashMap;


public class Student {
int sid, fee;
String sname, course;

public int getSid() {
	return sid;
}

public void setSid(int sid) {
	this.sid = sid;
}

public int getFee() {
	return fee;
}

public void setFee(int fee) {
	this.fee = fee;
}

public String getSname() {
	return sname;
}

public void setSname(String sname) {
	this.sname = sname;
}

public String getCourse() {
	return course;
}

public void setCourse(String course) {
	this.course = course;
}

public Student(int sid, int fee, String sname, String course) {
	this.sid = sid;
	this.fee = fee;
	this.sname = sname;
	this.course = course;
}

@Override
public String toString() {
	return "Student [sid=" + sid + ", fee=" + fee + ", sname=" + sname + ", course=" + course + "]";
}


}
