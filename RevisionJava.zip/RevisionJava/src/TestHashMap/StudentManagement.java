package TestHashMap;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.lang.model.element.NestingKind;

 class StudentManagement {

Scanner sc=new Scanner(System.in);
HashMap<Integer, Student> hm;

public  StudentManagement() {
	hm=new HashMap<Integer, Student>();
}

public void addstudent() {
	int sid, fee;
	String name,course;
	
	System.out.println("enter student id");
	 sid=sc.nextInt();
	System.out.println("enter student name");
	 name=sc.next();
	System.out.println("course");
	 course =sc.next();
	System.out.println("enter student fees");
	 fee=sc.nextInt();
	Student stu=new Student(sid, fee, name, course);
	hm.put(stu.sid, stu);
	System.out.println("student added successfully");
	
}

public void update() {
	
	System.out.println("endter student id");
	int id=sc.nextInt();
	
	for(Map.Entry<Integer,Student> entry : hm.entrySet()) 
	{
		
		Student stu=entry.getValue();
		if(stu.sid==id) {
			System.out.println("enter new name");
			String newname=sc.next();
			System.out.println("enter new course");
		 String newcourse=sc.next();
		 stu.setSname(newname);
		 stu.setCourse(newcourse);
		 System.out.println("student data updated for id"+id);
		}
	
	}
}
public void delete() {
	System.out.println("enter student id you want to delete");
	int sid=sc.nextInt();
	
	if(hm.containsKey(sid)) {
		hm.remove(sid);
		System.out.println("deleted successfully");
	}
}

public void display() 
{
	for(Map.Entry<Integer,Student> entry : hm.entrySet()) 
	{
		Student stu=entry.getValue();
		System.out.println(stu.toString());
	}
}
}
