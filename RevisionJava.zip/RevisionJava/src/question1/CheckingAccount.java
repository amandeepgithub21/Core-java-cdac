package question1;

public class CheckingAccount extends Account {
	double overdraftLimit;
public CheckingAccount(String accountNumber, String accountHolderName, double balance,double overdraftLimit) {
		super(accountNumber, accountHolderName, balance);
		this.overdraftLimit= overdraftLimit;;
	}

void withdraw(double amount) {
	if (balance +overdraftLimit>=amount) {
		balance -=amount;
		System.out.println("amount withrawal request"+amount);
	} else {
		System.out.println("withdrawl exceeding overdraft limit");
	}
}

}
