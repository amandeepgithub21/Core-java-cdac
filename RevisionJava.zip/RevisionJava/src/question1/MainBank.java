package question1;

import java.util.Scanner;

public class MainBank {
	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int ch;
	System.out.println("enter  saving account number:");
	String saccno=sc.next();
	System.out.println("enter  saving account holder name:");
	String saccholder=sc.next();
	System.out.println("enter saving account balance:");
	double sbal=sc.nextDouble();
	System.out.println("enter saving account instrest rate:");
	double sintrate=sc.nextDouble();
	
	SavingsAccount sa=new SavingsAccount(saccno, saccholder, sbal, sintrate);
	sa.applyInterest();

	System.out.println("enter  checking account number:");
	String caccno=sc.next();
	System.out.println("enter  checking account holder name:");
	String caccholder=sc.next();
	System.out.println("enter checking account balance:");
	double cbal=sc.nextDouble();
	System.out.println("enter checking account overdraft limit:");
	double coverdraft=sc.nextDouble();
	CheckingAccount ca=new CheckingAccount(caccno, caccholder, cbal, coverdraft);
	
	do {
		

	System.out.println("enter 1tdmtsa || enter 2twmfsa || enter 3twmfsca ||enter 4tdmtca || enter 5te ");
	
	System.out.println("enter choice ");
	ch=sc.nextInt();
	
	switch (ch) {
	case 1:

		System.out.println("enter money you want to deposit:");
		double damount =sc.nextDouble();
		sa.deposit(damount);
		System.out.println("transaction history");
		sa.displayAll();
		break;
	case 2:
		System.out.println("enter money you want to withraw:");
		double wamount =sc.nextDouble();
		sa.withdraw(wamount);
		System.out.println("transaction history");
		sa.displayAll();
		break;
		
	case 3:
		System.out.println("enter money you want to withraw from checking account:");
		double cwamount =sc.nextDouble();
		
		ca.withdraw(cwamount);
		System.out.println("transaction history");
		ca.displayAll();
		break;
		
	case 4:
		
		System.out.println("enter money you want to deposit to checking account:");
		double cdamount =sc.nextDouble();
		
		ca.deposit(cdamount);
		System.out.println("transaction history");
		ca.displayAll();
		break;
	case 5:
		System.out.println("exit");
		break;
		default:
			System.out.println("invalid choice");
		
	}
	}while(ch!=5);
}

}
