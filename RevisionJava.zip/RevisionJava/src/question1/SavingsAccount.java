package question1;

public class SavingsAccount extends Account {
	
	
	double interestRate;
 public SavingsAccount(String accountNumber, String accountHolderName, double balance, double interestRate) {
		super(accountNumber, accountHolderName, balance);
	this.interestRate=interestRate;
	}
 
 
 void applyInterest()
{
	 double intrestgain=balance*interestRate/100;
	 deposit(intrestgain);
	 
}
 
}
 