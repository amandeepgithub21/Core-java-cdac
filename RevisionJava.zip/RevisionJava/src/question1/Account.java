package question1;

class Account{
	
	String accountNumber, accountHolderName; 
	 
	double balance;
	
	
	public Account(String accountNumber, String accountHolderName, double balance) {
		
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
	}

	void deposit(double amount){
		balance +=amount;
		System.out.println("Amount deposited"+amount);
	}
	
	void withdraw(double amount) {
	if (balance>amount) {
		balance -=amount;
		System.out.println("Amount withrawl request"+amount);
	} else {
System.out.println("insufficiant  money");
	}
	
		
	}
	
	void getBalance() {
		
		System.out.println("Balance amount is: "+balance );
	}
	
	void displayAll() {
		System.out.println("Account no: "+accountNumber);
		System.out.println("Account holder name: "+accountHolderName);
		System.out.println("balance: "+balance);
	}
}