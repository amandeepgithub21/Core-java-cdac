package TestArraylist;
public class Book{
	String title, author;
	int isbn;
	boolean isavailable;
	
	
	public Book(String title, String author, int isbn, boolean isavailable) {
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.isavailable = isavailable;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public boolean isIsavailable() {
		return isavailable;
	}
	public void setIsavailable(boolean isavailable) {
		this.isavailable = isavailable;
	}
	
	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", isbn=" + isbn + ", isavailable=" + isavailable + "]";
	}
}