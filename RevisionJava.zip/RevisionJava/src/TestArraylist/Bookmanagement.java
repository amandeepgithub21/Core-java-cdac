package TestArraylist;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Bookmanagement {
	Scanner sc = new Scanner(System.in);
	List<Book> booklist;

	public Bookmanagement() {

		booklist = new ArrayList<Book>();
	}

	public void addbook() {
		String title, author;
		int isbn;
		boolean isavailable;
		System.out.println("enter title");
		title = sc.next();
		System.out.println("enter author");
		author = sc.next();
		System.out.println("enter isbn");
		isbn = sc.nextInt();
		System.out.println("enter is available");
		isavailable = sc.nextBoolean();
		Book book = new Book(title, author, isbn, isavailable);
		booklist.add(book);
	}

	public void delete() {
		String title;
		
		System.out.println("enter title");
		title = sc.next();
		
		for(int i=0;i<booklist.size();i++) 
		{
			if(booklist.get(i).getTitle().equalsIgnoreCase(title))
            {
				booklist.remove(i);
			}
		}
		
	}
	public void search() {
String title;
		
		System.out.println("enter title");
		title = sc.next();
		for(Book b : booklist) {
			if(b.getTitle().equalsIgnoreCase(title)) {
				 System.out.println(b.toString()); 
			}
		}
	}
	void displayAllBooks() {
		for(Book b : booklist) {
			
			System.out.println(b.toString());
			
		}
	}
	
	public void borrowBook() { 
		  System.out.print("Enter the Book Title :"); 
		  String tit =sc.next(); 
		  for(Book b : booklist) { 
		   if(b.getTitle().equals(tit)&& b.isavailable == true) { 
		    System.out.println(b); 
		    b.isavailable = false ; 
		    System.out.println("Book Borrowed"); 
		     
		   }
		   else if(b.title.equals(tit)&&b.isavailable == false)
			{
				System.out.println(" already borrowed");
				
				
			}
		  } 
		 }
	void returnbook() {
		System.out.println("enter title");
		String title = sc.next();
		
		for(Book b: booklist) {
			if(b.getTitle().equals(title)&& b.isavailable == false) { 
			     
			    b.isavailable = true ; 
				System.out.println("returned successfully");
			}
			else if(b.title.equals(title)&&b.isavailable == true)
			{
				System.out.println(" already returned");
				
				
			}
		
	}
	}
}
