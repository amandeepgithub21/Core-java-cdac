package TestArraylist;

public class MainClass {
public static void main(String[] args) {
	Bookmanagement bm=new Bookmanagement();
	bm.addbook();
	bm.addbook();
	bm.displayAllBooks();
	bm.borrowBook();
	bm.borrowBook();
	bm.returnbook();
	bm.returnbook();
//	bm.search();
//	bm.delete();
	bm.displayAllBooks();
	
}
}
