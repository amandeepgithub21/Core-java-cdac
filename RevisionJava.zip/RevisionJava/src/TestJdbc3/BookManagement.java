package TestJdbc3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class BookManagement {
	Scanner sc = new Scanner(System.in);

	private static final String URL = "jdbc:mysql://localhost:3306/LibraryManagement";
	private static final String USER = "root";
	private static final String PASSWORD = "Aman@1990";
	private Connection connection = null;

	public BookManagement() throws SQLException {
		connection = DriverManager.getConnection(URL, USER, PASSWORD);
		System.out.println("Connection established successfully 😊");

	}

	public void addBook1() throws SQLException {
		String query1 = "insert into library(bookId,title,author,isAvailable ) values(?,?,?,?);";
		System.out.println("enter bookid");
		int id = sc.nextInt();
		System.out.println("enter title");
		String title = sc.next();
		System.out.println("enter author");
		String author = sc.next();
		System.out.println("enter availbilty");
		boolean isAvailable = sc.nextBoolean();
		try (PreparedStatement ps = connection.prepareStatement(query1)) {
			ps.setInt(1, id);
			ps.setString(2, title);
			ps.setString(3, author);
			ps.setBoolean(4, isAvailable);
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	 public void display() throws SQLException { 
		  String query2 = "Select * from library"; 
		  Statement smt = connection.createStatement(); 
		  ResultSet rs = smt.executeQuery(query2); 
		  while(rs.next()) { 
		   System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+ 
		rs.getString(3)+" "+rs.getBoolean(4)); 
		  } 
		 }
	 
	 public void delete() throws SQLException { 
		  System.out.print("Enter The Id you Want to Delete :"); 
		  int id = sc.nextInt(); 
		  String query3 = "Delete from library where bookId = ?"; 
		  PreparedStatement ps = connection.prepareStatement(query3); 
		  ps.setInt(1, id); 
		  ps.executeUpdate(); 
		  System.out.println("ID Deleted Successfully "); 
		   
		 } 
	 public void update() throws SQLException { 
		  System.out.println("Enter New Title,author and Id"); 
		  String nt = sc.next(); 
		  String na = sc.next(); 
		  int id = sc.nextInt(); 
		  String query4 = "update library set title  = ? ,author = ? where bookId = ?"; 
		  PreparedStatement ps = connection.prepareStatement(query4); 
		  ps.setString(1, nt); 
		  ps.setString(2, na);
		  ps.setInt(3, id); 
		  ps.executeUpdate(); 
		  
		 } 
		 public void search() throws SQLException { 
		  System.out.print("Enter Title :"); 
		  String tit = sc.next(); 
		  String query5 = "Select * from library where title = ?"; 
		  PreparedStatement ps = connection.prepareStatement(query5); 
		  ps.setString(1,tit); 
		  ResultSet rs = ps.executeQuery(); 
		  if(rs.next()) {
			  System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+ rs.getString(3)+" "+rs.getBoolean(4)); 
					  } 
					  } 
}