package TestJdbc3;

import java.sql.SQLException;

public class Mainclass {
	public static void main(String[] args) throws SQLException {
		BookManagement bm= new BookManagement();
		//bm.addBook1();
		//bm.display();
		//bm.delete();
		bm.display();
		bm.update();
		bm.search();
	}
	
}
