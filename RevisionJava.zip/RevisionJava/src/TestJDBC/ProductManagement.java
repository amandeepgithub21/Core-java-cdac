package TestJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductManagement {

Connection conn;

public ProductManagement()  throws ClassNotFoundException, SQLException{
	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/productmanagementSystem","root","Aman@1990");
	
}
public List<Product> getAll() throws SQLException {
	ArrayList<Product> list = new ArrayList<>();
	 Statement s=conn.createStatement();
	 ResultSet rs =s.executeQuery("select * from Products");
	 while(rs.next()) {
		list.add(new Product(rs.getInt("pId"),rs.getString("pName"),rs.getInt("price")));
		System.out.println(rs.getInt("pId")+rs.getString("pName")+rs.getInt("price"));
	 }
	 return list;
	 
}
	 public void addProduct(Product p) throws SQLException {
			PreparedStatement s = conn.prepareStatement("insert into Products values(?,?,?)");
			s.setInt(1, p.pId);
			s.setString(2, p.pName);
			s.setInt(3, p.price);
			s.execute();
		}
		public void deleteProduct(int Id) throws SQLException {
			
			PreparedStatement s= conn.prepareStatement("delete from Products where pId=?");
			s.setInt(1, Id);
	        s.execute();
		}
		public void updateProduct(Product p) throws SQLException {
			PreparedStatement s = conn.prepareStatement("update Products set pName=?,price=? where pId=?");
			s.setString(1, p.pName);
			s.setInt(2, p.price);
			s.setInt(3, p.pId);
			s.executeUpdate();
		}
		public Product searchProduct(int id) throws SQLException {
			PreparedStatement s = conn.prepareStatement("select * from Products where pId=?");
			s.setInt(1, id);
			ResultSet rs = s.executeQuery();
			rs.next();
			return new Product(rs.getInt("pId"),rs.getString("pName"),rs.getInt("price"));
		
		}
		
		
		
		
	}
