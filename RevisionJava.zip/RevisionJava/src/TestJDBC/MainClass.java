package TestJDBC;

import java.sql.SQLException;

public class MainClass{
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		ProductManagement pm = new ProductManagement();
		pm.getAll();
		pm.addProduct(new Product(9,"mobile",1));
		pm.addProduct(new Product(11,"watch",2));
		pm.addProduct(new Product(10,"table",3));
		

		pm.deleteProduct(9);
		pm.getAll();
		
		Product p=pm.searchProduct(11);
		System.out.println(p);
		
		pm.updateProduct(new Product(10, "tv", 10));
		pm.getAll();
	}
}