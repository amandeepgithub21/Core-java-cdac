package test;

class NumPyramid{
	
	
	private static  void Showpyramid(int par) {
		for(int i=1,sum=0;i<=par;i++) 
		{
			System.out.println(sum=sum*10+i);
		}
		
	}
	public static void main(String[] args) {
		Showpyramid(5);
	}
}